package com.aem.community.core.models;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aem.community.core.constants.GlobalConstants;
import com.aem.community.core.utils.HeaderFooterUtility;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The Class HeaderModel.
 * 
 * @author Siddharth
 */
@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, resourceType = "HPIT-AEM-GLOBALNAV/components/content/header", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", selector = "headerService", extensions = "json", options = {
		@ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class HeaderModel {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(HeaderModel.class);

	/** The resource. */
	Resource resource;

	/** The request. */
	@JsonIgnore
	@Inject
	public SlingHttpServletRequest request;

	/** The current page. */
	@Inject
	private Page currentPage;

	/** The hp logo. */
	@Inject
	@Via("resource")
	private String hpLogo;

	/** The hp logo tool tip text. */
	@Inject
	@Via("resource")
	private String hpLogoToolTipText;

	/** The logo redirection url. */
	@Inject
	@Via("resource")
	private String logoRedirectionUrl;

	/** The analytics link type for logo. */
	@Inject
	@Via("resource")
	private String analyticsLinkTypeForLogo;

	/** The analytics link placement for logo. */
	@Inject
	@Via("resource")
	private String analyticsLinkPlacementForLogo;

	/** The analytics link ID for logo. */
	@Inject
	@Via("resource")
	private String analyticsLinkIDForLogo;

	/** The search text. */
	@Inject
	@Via("resource")
	private String searchText;

	/** The search icon tool tip text. */
	@Inject
	@Via("resource")
	private String searchIconToolTipText;

	/** The tab tool tip text. */
	@Inject
	@Via("resource")
	private String tabToolTipText;
	
	/** The analytics link type for search. */
	@Inject
	@Via("resource")
	private String analyticsLinkTypeForSearch;

	/** The analytics link placement for search. */
	@Inject
	@Via("resource")
	private String analyticsLinkPlacementForSearch;

	/** The analytics link ID for search. */
	@Inject
	@Via("resource")
	private String analyticsLinkIDForSearch;

	/** The search result url. */
	@Inject
	@Via("resource")
	private String searchResultUrl;

	/** The auto suggest text allof hp. */
	@Inject
	@Via("resource")
	private String autoSuggestTextAllofHp;

	/** The searching text allof hp. */
	@Inject
	@Via("resource")
	private String searchingTextAllofHp;

	/** The No Result text for all of hp. */
	@Inject
	@Via("resource")
	private String noResultAllHp;

	/** The auto suggest url allof hp. */
	@Inject
	@Via("resource")
	private String autoSuggestUrlAllofHp;

	/** The search result url hp store. */
	@Inject
	@Via("resource")
	private String searchResultUrlHpStore;

	/** The auto suggest text hp store. */
	@Inject
	@Via("resource")
	private String autoSuggestTextHpStore;

	/** The searching text hp store. */
	@Inject
	@Via("resource")
	private String searchingTextHpStore;

	/** The No result text for store hp. */
	@Inject
	@Via("resource")
	private String noResultStoreHp;

	/** The auto suggest url hp store. */
	@Inject
	@Via("resource")
	private String autoSuggestUrlHpStore;

	/** The auto suggest service url. */

	@Inject
	@Via("resource")
	private String searchResultServiceUrl;

	/** The auto suggest service text. */
	@Inject
	@Via("resource")
	private String autoSuggestServiceText;

	/** The searching text for service. */
	@Inject
	@Via("resource")
	private String searchingTextForService;

	/** The no result service. */
	@Inject
	@Via("resource")
	private String noResultService;

	/** The auto suggest service url. */
	@Inject
	@Via("resource")
	private String autoSuggestServiceUrl;

	/** The cart icon tool tip text. */
	@Inject
	@Via("resource")
	private String cartIconToolTipText;

	/** The cart redirection url. */
	@Inject
	@Via("resource")
	private String cartRedirectionUrl;

	/** The cart visibility. */
	@Inject
	@Via("resource")
	private String cartVisibility;

	/** The cart service url. */
	@Inject
	@Via("resource")
	private String cartServiceUrl;
	
	/** The analytics link type for cart. */
	@Inject
	@Via("resource")
	private String analyticsLinkTypeForCart;

	/** The analytics link placement for cart. */
	@Inject
	@Via("resource")
	private String analyticsLinkPlacementForCart;

	/** The analytics link ID for cart. */
	@Inject
	@Via("resource")
	private String analyticsLinkIDForCart;

	/** The main title 1. */
	@Inject
	@Via("resource")
	private String mainTitle1;

	/** The main title 2. */
	@Inject
	@Via("resource")
	private String mainTitle2;

	/** The main title 3. */
	@Inject
	@Via("resource")
	private String mainTitle3;

	/** The tab 1 parent list. */
	@Inject
	@Via("resource")
	private List<Resource> tab1ParentList;

	/** The tab 2 parent list. */
	@Inject
	@Via("resource")
	private List<Resource> tab2ParentList;

	/** The tab 3 parent list. */
	@Inject
	@Via("resource")
	private List<Resource> tab3ParentList;

	/** The menu open. */
	@Inject
	@Via("resource")
	private String menuOpen;

	/** The menu close. */
	@Inject
	@Via("resource")
	private String menuClose;

	/** The search close. */
	@Inject
	@Via("resource")
	private String searchClose;

	/** The back. */
	@Inject
	@Via("resource")
	private String back;

	/** The inside. */
	@Inject
	@Via("resource")
	private String inside;

	/** The open menu prefix. */
	@Inject
	@Via("resource")
	private String openMenuPrefix;

	/** The open menu suffix. */
	@Inject
	@Via("resource")
	private String openMenuSuffix;

	/** The close menu prefix. */
	@Inject
	@Via("resource")
	private String closeMenuPrefix;

	/** The close menu suffix. */
	@Inject
	@Via("resource")
	private String closeMenuSuffix;

	/** The opened state menu prefix. */
	@Inject
	@Via("resource")
	private String openedStateMenuPrefix;

	/** The opened state menu suffix. */
	@Inject
	@Via("resource")
	private String openedStateMenuSuffix;

	/** The closed state menu prefix. */
	@Inject
	@Via("resource")
	private String closedStateMenuPrefix;

	/** The closed state menu suffix. */
	@Inject
	@Via("resource")
	private String closedStateMenuSuffix;

	/** The opened state submenu suffix. */
	@Inject
	@Via("resource")
	private String openedStateSubmenuSuffix;

	/** The selected country state. */
	@Inject
	@Via("resource")
	private String selectedCountryState;

	/** The open popup prefix. */
	@Inject
	@Via("resource")
	private String openPopupPrefix;

	/** The open popup suffix. */
	@Inject
	@Via("resource")
	private String openPopupSuffix;

	/** The close popup prefix. */
	@Inject
	@Via("resource")
	private String closePopupPrefix;

	/** The close popup suffix. */
	@Inject
	@Via("resource")
	private String closePopupSuffix;

	/** The expand prefix. */
	@Inject
	@Via("resource")
	private String expandPrefix;

	/** The expand suffix. */
	@Inject
	@Via("resource")
	private String expandSuffix;

	/** The collapse prefix. */
	@Inject
	@Via("resource")
	private String collapsePrefix;

	/** The collapse suffix. */
	@Inject
	@Via("resource")
	private String collapseSuffix;

	/** The search box suggestion title. */
	@Inject
	@Via("resource")
	private String searchBoxSuggestionTitle;

	/** The search box close title. */
	@Inject
	@Via("resource")
	private String searchBoxCloseTitle;

	/** The country code. */
	private String countryCode;

	/** The language code. */
	private String languageCode;

	/** The header item list. */
	private List<HeaderItemModel> headerItemList1;

	/** The header item list 2. */
	private List<HeaderItemModel> headerItemList2;

	/** The header item list 3. */
	private List<HeaderItemModel> headerItemList3;

	/**
	 * Inits the.
	 */
	@PostConstruct
	public void init() {
		Page countryPage = currentPage.getAbsoluteParent(2);
		if (countryPage != null && countryPage.getName() != null
				&& (countryPage.getProperties().get(GlobalConstants.LANGUAGE_CODE, String.class)) != null) {
			countryCode = countryPage.getName();
			languageCode = countryPage.getProperties().get(GlobalConstants.LANGUAGE_CODE, String.class);

			this.headerItemList1 = buildMenuItems1();
			this.headerItemList2 = buildMenuItems2();
			this.headerItemList3 = buildMenuItems3();
		}
	}

	/**
	 * Builds the menu items.
	 *
	 * @return the list
	 */
	private List<HeaderItemModel> buildMenuItems1() {
		List<HeaderItemModel> mItems = new ArrayList<>();
		if (this.tab1ParentList != null) {

			for (Resource r : this.tab1ParentList) {
				HeaderItemModel hmi = r.adaptTo(HeaderItemModel.class);
				mItems.add(hmi);
			}
		} else {
			LOGGER.error("Error when instantiating Header. {}");
		}

		return mItems;
	}

	/**
	 * Builds the menu items 2.
	 *
	 * @return the list
	 */
	private List<HeaderItemModel> buildMenuItems2() {
		List<HeaderItemModel> mItems = new ArrayList<>();
		if (this.tab2ParentList != null) {

			for (Resource r : this.tab2ParentList) {
				HeaderItemModel hmi = r.adaptTo(HeaderItemModel.class);
				mItems.add(hmi);
			}
		} else {
			LOGGER.error("Error when instantiating Header. {}");
		}

		return mItems;
	}

	/**
	 * Builds the menu items 3.
	 *
	 * @return the list
	 */
	private List<HeaderItemModel> buildMenuItems3() {
		List<HeaderItemModel> mItems = new ArrayList<>();
		if (this.tab3ParentList != null) {

			for (Resource r : this.tab3ParentList) {
				HeaderItemModel hmi = r.adaptTo(HeaderItemModel.class);
				mItems.add(hmi);
			}
		} else {
			LOGGER.error("Error when instantiating Header. {}");
		}

		return mItems;
	}

	/**
	 * Gets the header item list 1.
	 *
	 * @return the header item list 1
	 */
	public List<HeaderItemModel> getHeaderItemList1() {
		linkchecker(headerItemList1);
		return this.headerItemList1;
	}

	/**
	 * Gets the header item list 2.
	 *
	 * @return the header item list 2
	 */
	public List<HeaderItemModel> getHeaderItemList2() {
		linkchecker(headerItemList2);
		return this.headerItemList2;
	}

	/**
	 * Gets the header item list 3.
	 *
	 * @return the header item list 3
	 */
	public List<HeaderItemModel> getHeaderItemList3() {
		linkchecker(headerItemList3);
		return this.headerItemList3;
	}

	/**
	 * Linkchecker.
	 *
	 * @param headerItemList
	 *            the header item list
	 */
	public void linkchecker(List<HeaderItemModel> headerItemList) {
		HeaderSubMenuItemModel headerSubMenuItemModel;
		List<HeaderSubMenuItemModel> headerSubMenuItemModelsList = new ArrayList<HeaderSubMenuItemModel>();
		for (int i = 0; i < headerItemList.size(); i++) {

			headerSubMenuItemModel = new HeaderSubMenuItemModel();
			if (headerItemList.equals(headerItemList1)) {
				headerSubMenuItemModelsList = headerItemList.get(i).getTab1List();
			}
			if (headerItemList.equals(headerItemList2)) {
				headerSubMenuItemModelsList = headerItemList.get(i).getTab2List();
			}
			if (headerItemList.equals(headerItemList3)) {
				headerSubMenuItemModelsList = headerItemList.get(i).getTab3List();
			}
			headerSubMenuItemModel = new HeaderSubMenuItemModel();
			for (int j = 0; j < headerSubMenuItemModelsList.size(); j++) {
				headerSubMenuItemModel = headerSubMenuItemModelsList.get(j);

				headerSubMenuItemModel.setSubChildPath(
						HeaderFooterUtility.linkCheck(headerSubMenuItemModel.getSubChildPath(), request, getCountryCode(), getLanguageCode()));
			}
		}
	}

	/**
	 * Gets the country code.
	 *
	 * @return the country code
	 */
	public String getCountryCode() {
		if (countryCode == null) {
			countryCode = GlobalConstants.COUNTRY_CODE_US;
		}
		return countryCode;
	}

	/**
	 * Gets the language code.
	 *
	 * @return the language code
	 */
	public String getLanguageCode() {
		if (languageCode == null) {
			languageCode = GlobalConstants.LANGUAGE_CODE_EN;
		}
		return languageCode;
	}

	/**
	 * Gets the search text.
	 *
	 * @return the search text
	 */
	public String getSearchText() {
		return searchText;
	}

	/**
	 * Gets the search result url.
	 *
	 * @return the search result url
	 */
	public String getSearchResultUrl() {
		return HeaderFooterUtility.linkCheck(searchResultUrl, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the search result url hp store.
	 *
	 * @return the search result url hp store
	 */
	public String getSearchResultUrlHpStore() {
		return HeaderFooterUtility.linkCheck(searchResultUrlHpStore, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the auto suggest url allof hp.
	 *
	 * @return the auto suggest url allof hp
	 */
	public String getAutoSuggestUrlAllofHp() {
		return HeaderFooterUtility.linkCheck(autoSuggestUrlAllofHp, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the searching text allof hp.
	 *
	 * @return the searching text allof hp
	 */
	public String getSearchingTextAllofHp() {
		return searchingTextAllofHp;
	}

	/**
	 * Gets the no Result text allof hp.
	 *
	 * @return the no Result text allof hp
	 */
	public String getNoResultAllHp() {
		return noResultAllHp;
	}

	/**
	 * Gets the no result text for hp Store.
	 *
	 * @return the no result text for hp Store
	 */
	public String getNoResultStoreHp() {
		return noResultStoreHp;
	}

	/**
	 * Gets the auto suggest url hp store.
	 *
	 * @return the auto suggest url hp store
	 */
	public String getAutoSuggestUrlHpStore() {
		return HeaderFooterUtility.linkCheck(autoSuggestUrlHpStore, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the search result service url.
	 *
	 * @return the search result service url
	 */
	public String getSearchResultServiceUrl() {
		return HeaderFooterUtility.linkCheck(searchResultServiceUrl, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the searching text for service.
	 *
	 * @return the searching text for service
	 */
	public String getSearchingTextForService() {
		return searchingTextForService;
	}

	/**
	 * Gets the no result service.
	 *
	 * @return the no result service
	 */
	public String getNoResultService() {
		return noResultService;
	}

	/**
	 * Gets the auto suggest service url.
	 *
	 * @return the auto suggest service url
	 */
	public String getAutoSuggestServiceUrl() {
		return HeaderFooterUtility.linkCheck(autoSuggestServiceUrl, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the cart redirection url.
	 *
	 * @return the cart redirection url
	 */
	public String getCartRedirectionUrl() {
		return HeaderFooterUtility.linkCheck(cartRedirectionUrl, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the logo redirection url.
	 *
	 * @return the logo redirection url
	 */
	public String getLogoRedirectionUrl() {
		return HeaderFooterUtility.linkCheck(logoRedirectionUrl, request, getCountryCode(), getLanguageCode());
	}

	/**
	 * Gets the analytics link type for logo.
	 *
	 * @return the analytics link type for logo
	 */
	public String getAnalyticsLinkTypeForLogo() {
		return analyticsLinkTypeForLogo;
	}

	/**
	 * Gets the analytics link placement for logo.
	 *
	 * @return the analytics link placement for logo
	 */
	public String getAnalyticsLinkPlacementForLogo() {
		return analyticsLinkPlacementForLogo;
	}

	/**
	 * Gets the analytics link ID for logo.
	 *
	 * @return the analytics link ID for logo
	 */
	public String getAnalyticsLinkIDForLogo() {
		return analyticsLinkIDForLogo;
	}

	/**
	 * Gets the cart visibility.
	 *
	 * @return the cart visibility
	 */
	public String getCartVisibility() {
		return cartVisibility;
	}

	/**
	 * Check cart visibility.
	 *
	 * @return the boolean
	 */
	public Boolean checkCartVisibility() {
		try {
			if (getCartVisibility().equalsIgnoreCase(GlobalConstants.YES)) {
				if (request.getParameter(GlobalConstants.SHOW_SHOPPING_CART) != null && request
						.getParameter(GlobalConstants.SHOW_SHOPPING_CART).equalsIgnoreCase(GlobalConstants.TRUE)) {
					return true;
				} else if (request.getParameter(GlobalConstants.SHOW_SHOPPING_CART) != null && request
						.getParameter(GlobalConstants.SHOW_SHOPPING_CART).equalsIgnoreCase(GlobalConstants.FALSE)) {
					return false;
				} else {
					return true;
				}
			}
			if (getCartVisibility().equalsIgnoreCase(GlobalConstants.NO)) {
				if (request.getParameter(GlobalConstants.SHOW_SHOPPING_CART) != null && request
						.getParameter(GlobalConstants.SHOW_SHOPPING_CART).equalsIgnoreCase(GlobalConstants.TRUE)) {
					return true;
				} else {
					return false;
				}
			}

		} catch (Exception e) {
			LOGGER.error("There is an error {}", e);
		}
		return false;
	}

	/**
	 * Gets the cart service url.
	 *
	 * @return the cart service url
	 */
	public String getCartServiceUrl() {
		return HeaderFooterUtility.linkCheck(cartServiceUrl, request, getCountryCode(), getLanguageCode());
	}	

	/**
	 * Gets the analytics link type for cart.
	 *
	 * @return the analytics link type for cart
	 */
	public String getAnalyticsLinkTypeForCart() {
		return analyticsLinkTypeForCart;
	}

	/**
	 * Gets the analytics link placement for cart.
	 *
	 * @return the analytics link placement for cart
	 */
	public String getAnalyticsLinkPlacementForCart() {
		return analyticsLinkPlacementForCart;
	}

	/**
	 * Gets the analytics link ID for cart.
	 *
	 * @return the analytics link ID for cart
	 */
	public String getAnalyticsLinkIDForCart() {
		return analyticsLinkIDForCart;
	}

	/**
	 * Gets the search icon tool tip text.
	 *
	 * @return the search icon tool tip text
	 */
	public String getSearchIconToolTipText() {
		return searchIconToolTipText;
	}

	/**
	 * Gets the tab tool tip text.
	 *
	 * @return the tab tool tip text
	 */
	public String getTabToolTipText() {
		return tabToolTipText;
	}
	
	/**
	 * Gets the analytics link type for search.
	 *
	 * @return the analytics link type for search
	 */
	public String getAnalyticsLinkTypeForSearch() {
		return analyticsLinkTypeForSearch;
	}

	/**
	 * Gets the analytics link placement for search.
	 *
	 * @return the analytics link placement for search
	 */
	public String getAnalyticsLinkPlacementForSearch() {
		return analyticsLinkPlacementForSearch;
	}

	/**
	 * Gets the analytics link ID for search.
	 *
	 * @return the analytics link ID for search
	 */
	public String getAnalyticsLinkIDForSearch() {
		return analyticsLinkIDForSearch;
	}

	/**
	 * Gets the auto suggest text allof hp.
	 *
	 * @return the auto suggest text allof hp
	 */
	public String getAutoSuggestTextAllofHp() {
		return autoSuggestTextAllofHp;
	}

	/**
	 * Gets the auto suggest text hp store.
	 *
	 * @return the auto suggest text hp store
	 */
	public String getAutoSuggestTextHpStore() {
		return autoSuggestTextHpStore;
	}

	/**
	 * Gets the searching text hp store.
	 *
	 * @return the searching text hp store
	 */
	public String getSearchingTextHpStore() {
		return searchingTextHpStore;
	}

	/**
	 * Gets the auto suggest service text.
	 *
	 * @return the auto suggest service text
	 */
	public String getAutoSuggestServiceText() {
		return autoSuggestServiceText;
	}

	/**
	 * Gets the hp logo.
	 *
	 * @return the hp logo
	 */
	public String getHpLogo() {
		return HeaderFooterUtility.damLinkCheck(hpLogo, request);
	}

	/**
	 * Gets the hp logo tool tip text.
	 *
	 * @return the hp logo tool tip text
	 */
	public String getHpLogoToolTipText() {
		return hpLogoToolTipText;
	}

	/**
	 * Gets the cart icon tool tip text.
	 *
	 * @return the cart icon tool tip text
	 */
	public String getCartIconToolTipText() {
		return cartIconToolTipText;
	}

	/**
	 * Gets the main title 1.
	 *
	 * @return the main title 1
	 */
	public String getMainTitle1() {
		return mainTitle1;
	}

	/**
	 * Gets the main title 2.
	 *
	 * @return the main title 2
	 */
	public String getMainTitle2() {
		return mainTitle2;
	}

	/**
	 * Gets the main title 3.
	 *
	 * @return the main title 3
	 */
	public String getMainTitle3() {
		return mainTitle3;
	}

	/**
	 * Gets the menu open.
	 *
	 * @return the menu open
	 */
	public String getMenuOpen() {
		return menuOpen;
	}

	/**
	 * Gets the menu close.
	 *
	 * @return the menu close
	 */
	public String getMenuClose() {
		return menuClose;
	}

	/**
	 * Gets the search close.
	 *
	 * @return the search close
	 */
	public String getSearchClose() {
		return searchClose;
	}

	/**
	 * Gets the back.
	 *
	 * @return the back
	 */
	public String getBack() {
		return back;
	}

	/**
	 * Gets the inside.
	 *
	 * @return the inside
	 */
	public String getInside() {
		return inside;
	}

	/**
	 * Gets the open menu prefix.
	 *
	 * @return the open menu prefix
	 */
	public String getOpenMenuPrefix() {
		return openMenuPrefix;
	}

	/**
	 * Gets the open menu suffix.
	 *
	 * @return the open menu suffix
	 */
	public String getOpenMenuSuffix() {
		return openMenuSuffix;
	}

	/**
	 * Gets the close menu prefix.
	 *
	 * @return the close menu prefix
	 */
	public String getCloseMenuPrefix() {
		return closeMenuPrefix;
	}

	/**
	 * Gets the close menu suffix.
	 *
	 * @return the close menu suffix
	 */
	public String getCloseMenuSuffix() {
		return closeMenuSuffix;
	}

	/**
	 * Gets the opened state menu prefix.
	 *
	 * @return the opened state menu prefix
	 */
	public String getOpenedStateMenuPrefix() {
		return openedStateMenuPrefix;
	}

	/**
	 * Gets the opened state menu suffix.
	 *
	 * @return the opened state menu suffix
	 */
	public String getOpenedStateMenuSuffix() {
		return openedStateMenuSuffix;
	}

	/**
	 * Gets the closed state menu prefix.
	 *
	 * @return the closed state menu prefix
	 */
	public String getClosedStateMenuPrefix() {
		return closedStateMenuPrefix;
	}

	/**
	 * Gets the closed state menu suffix.
	 *
	 * @return the closed state menu suffix
	 */
	public String getClosedStateMenuSuffix() {
		return closedStateMenuSuffix;
	}

	/**
	 * Gets the opened state submenu suffix.
	 *
	 * @return the opened state submenu suffix
	 */
	public String getOpenedStateSubmenuSuffix() {
		return openedStateSubmenuSuffix;
	}

	/**
	 * Gets the open popup prefix.
	 *
	 * @return the open popup prefix
	 */
	public String getOpenPopupPrefix() {
		return openPopupPrefix;
	}

	/**
	 * Gets the open popup suffix.
	 *
	 * @return the open popup suffix
	 */
	public String getOpenPopupSuffix() {
		return openPopupSuffix;
	}

	/**
	 * Gets the close popup prefix.
	 *
	 * @return the close popup prefix
	 */
	public String getClosePopupPrefix() {
		return closePopupPrefix;
	}

	/**
	 * Gets the close popup suffix.
	 *
	 * @return the close popup suffix
	 */
	public String getClosePopupSuffix() {
		return closePopupSuffix;
	}

	/**
	 * Gets the expand prefix.
	 *
	 * @return the expand prefix
	 */
	public String getExpandPrefix() {
		return expandPrefix;
	}

	/**
	 * Gets the expand suffix.
	 *
	 * @return the expand suffix
	 */
	public String getExpandSuffix() {
		return expandSuffix;
	}

	/**
	 * Gets the collapse prefix.
	 *
	 * @return the collapse prefix
	 */
	public String getCollapsePrefix() {
		return collapsePrefix;
	}

	/**
	 * Gets the collapse suffix.
	 *
	 * @return the collapse suffix
	 */
	public String getCollapseSuffix() {
		return collapseSuffix;
	}

	/**
	 * Gets the search box suggestion title.
	 *
	 * @return the search box suggestion title
	 */
	public String getSearchBoxSuggestionTitle() {
		return searchBoxSuggestionTitle;
	}

	/**
	 * Gets the search box close title.
	 *
	 * @return the search box close title
	 */
	public String getSearchBoxCloseTitle() {
		return searchBoxCloseTitle;
	}

	/**
	 * Gets the selected country state.
	 *
	 * @return the selected country state
	 */
	public String getSelectedCountryState() {
		return selectedCountryState;
	}

}