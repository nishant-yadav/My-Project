package com.aem.community.core.models;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The Class HeaderItemModel.
 * @author Siddharth
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class HeaderItemModel {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(HeaderItemModel.class);

	/** The sub title. */
	@Inject
	private String subTitle;

	/** The tab 1 list. */
	@Inject
	private List<Resource> tab1List;

	/** The tab 2 list. */
	@Inject
	private List<Resource> tab2List;

	/** The tab 3 list. */
	@Inject
	private List<Resource> tab3List;

	/** The sub menu list 1. */
	private List<HeaderSubMenuItemModel> subMenuList1;

	/** The sub menu list 2. */
	private List<HeaderSubMenuItemModel> subMenuList2;

	/** The sub menu list 3. */
	private List<HeaderSubMenuItemModel> subMenuList3;

	/**
	 * Inits the.
	 */
	@PostConstruct
	private void init() {
		this.subMenuList1 = buildSubMenus1();
		this.subMenuList2 = buildSubMenus2();
		this.subMenuList3 = buildSubMenus3();
	}

	/**
	 * Builds the sub menus 1.
	 *
	 * @return the list
	 */
	private List<HeaderSubMenuItemModel> buildSubMenus1() {
		List<HeaderSubMenuItemModel> subMenuItems = new ArrayList<>();

		if (this.tab1List != null) {

			for (Resource r : this.tab1List) {
				HeaderSubMenuItemModel headerSubMenuItemModel = r.adaptTo(HeaderSubMenuItemModel.class);
				subMenuItems.add(headerSubMenuItemModel);
			}
		} else {
			LOGGER.debug("Sub Menus not available :");
		}

		return subMenuItems;

	}

	/**
	 * Builds the sub menus 2.
	 *
	 * @return the list
	 */
	private List<HeaderSubMenuItemModel> buildSubMenus2() {
		List<HeaderSubMenuItemModel> subMenuItems = new ArrayList<>();

		if (this.tab2List != null) {

			for (Resource r : this.tab2List) {
				HeaderSubMenuItemModel headerSubMenuItemModel = r.adaptTo(HeaderSubMenuItemModel.class);
				subMenuItems.add(headerSubMenuItemModel);
			}
		} else {
			LOGGER.debug("Sub Menus not available :");
		}

		return subMenuItems;
	}

	/**
	 * Builds the sub menus 3.
	 *
	 * @return the list
	 */
	private List<HeaderSubMenuItemModel> buildSubMenus3() {
		List<HeaderSubMenuItemModel> subMenuItems = new ArrayList<>();

		if (this.tab3List != null) {

			for (Resource r : this.tab3List) {
				HeaderSubMenuItemModel headerSubMenuItemModel = r.adaptTo(HeaderSubMenuItemModel.class);
				subMenuItems.add(headerSubMenuItemModel);
			}
		} else {
			LOGGER.debug("Sub Menus not available :");
		}

		return subMenuItems;
	}

	/**
	 * Gets the tab 1 list.
	 *
	 * @return the tab 1 list
	 */
	public List<HeaderSubMenuItemModel> getTab1List() {
		return this.subMenuList1;
	}

	/**
	 * Gets the tab 2 list.
	 *
	 * @return the tab 2 list
	 */
	public List<HeaderSubMenuItemModel> getTab2List() {
		return this.subMenuList2;
	}

	/**
	 * Gets the tab 3 list.
	 *
	 * @return the tab 3 list
	 */
	public List<HeaderSubMenuItemModel> getTab3List() {
		return this.subMenuList3;
	}

	/**
	 * Gets the sub title.
	 *
	 * @return the sub title
	 */
	public String getSubTitle() {
		return subTitle;
	}

}
