package com.aem.community.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The Class HeaderSubMenuItemModel.
 * 
 * @author Siddharth
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class HeaderSubMenuItemModel {

	/** The sub child title. */
	@Inject
	private String subChildTitle;

	/** The sub child path. */
	@Inject
	private String subChildPath;

	/** The target. */
	@Inject
	private String target;

	/**
	 * Gets the target.
	 *
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}

	/** The analytics link type. */
	@Inject
	private String analyticsLinkType;

	/** The analytics link placement. */
	@Inject
	private String analyticsLinkPlacement;

	/** The analytics link ID. */
	@Inject
	private String analyticsLinkID;

	/**
	 * Gets the sub child title.
	 *
	 * @return the sub child title
	 */
	public String getSubChildTitle() {
		return subChildTitle;
	}

	/**
	 * Gets the sub child path.
	 *
	 * @return the sub child path
	 */
	public String getSubChildPath() {
		return subChildPath;
	}

	/**
	 * Sets the sub child path.
	 *
	 * @param subChildPath
	 *            the new sub child path
	 */
	public void setSubChildPath(String subChildPath) {
		this.subChildPath = subChildPath;
	}

	/**
	 * Gets the analytics link type.
	 *
	 * @return the analytics link type
	 */
	public String getAnalyticsLinkType() {
		return analyticsLinkType;
	}

	/**
	 * Gets the analytics link placement.
	 *
	 * @return the analytics link placement
	 */
	public String getAnalyticsLinkPlacement() {
		return analyticsLinkPlacement;
	}

	/**
	 * Gets the analytics link ID.
	 *
	 * @return the analytics link ID
	 */
	public String getAnalyticsLinkID() {
		return analyticsLinkID;
	}

}
