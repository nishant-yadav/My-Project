package com.aem.community.core.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.servlets.post.JSONResponse;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.social.tally.client.api.Response;

/*** @author Teja G **/ 
//@SlingServlet(paths = "/bin/aeminmyway/getRecaptchaResponseServlet")
@Component(immediate = true, service = Servlet.class, property = {
"sling.servlet.paths=/bin/getRecaptchaResponseServlet" })

public class GetRecaptchaResponseServlet extends SlingAllMethodsServlet{
	
	private static final Logger log = LoggerFactory.getLogger(GetRecaptchaResponseServlet.class);
	
String SECRET_KEY = "6Lez0dIZAAAAAJep2BirMHZlOqEdjB1ohExf53Do";

@Override
protected void doGet(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
		throws ServletException, IOException {
	
	isCaptchaValid(SECRET_KEY, resp);
	resp.getWriter();
}

public Boolean isCaptchaValid(String secretKey, SlingHttpServletResponse response) {
    try {
        String url = "https://www.google.com/recaptcha/api/siteverify",
                params = "secret=" + secretKey + "&response=" + response;

        HttpURLConnection http = (HttpURLConnection) new URL(url).openConnection();
        http.setDoOutput(true);
        http.setRequestMethod("POST");
        http.setRequestProperty("Content-Type",
                "application/x-www-form-urlencoded; charset=UTF-8");
        OutputStream out = http.getOutputStream();
        out.write(params.getBytes("UTF-8"));
        out.flush();
        out.close();

        InputStream res = http.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(res, "UTF-8"));

        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        log.info("response  :::::::: "+sb);
        JSONObject json = new JSONObject(sb.toString());
        res.close();

        return json.getBoolean("success");
    } catch (Exception e) {
        System.out.println("Exception ::::::: "+e);
    }
    return false;
}
}

/*public class GetRecaptchaResponseServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static final String RESPONSETYPE = "application/json";
	private static final Logger log = LoggerFactory.getLogger(GetRecaptchaResponseServlet.class);
	private static final String UTF8 = "UTF-8";
	
	@Override
	protected void doGet(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
			throws ServletException, IOException {
		
		 * javax.net.ssl.SSLHandshakeException: Remote host closed connection during handshake exception fix
		 * System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		 
		log.debug(":::::::::::::: GetRecaptchaResponseServlet POST() Starts :::::::::::::");
		String response = "";
		response = getResponse(req);
		resp.setContentType(RESPONSETYPE);
		resp.getWriter().write(response);
		log.debug(":::::::::::::: GetRecaptchaResponseServlet POST() Ends :::::::::::::");
	}

	public String getResponse(SlingHttpServletRequest req) {
		log.info("req   :::: "+req);
		String response = "[]";
		String str = req.getParameter("g-recaptcha-response") != null ? req.getParameter("g-recaptcha-response") : "";
		String configUrl = "https://www.google.com/recaptcha/api/siteverify?secret=6Lez0dIZAAAAAJep2BirMHZlOqEdjB1ohExf53Do"
				+ "&response=" + str;
		log.info("configUrl  :::: "+configUrl);
		try {
			log.debug("::: Params :: token:: " + str);
			if (str != null) {
				String baseUrl = configUrl;
				CloseableHttpClient client = null;
				HttpClientBuilder httpClientBuilder = null;
				httpClientBuilder = HttpClientBuilder.create();
				client = httpClientBuilder.build();
				HttpGet request = new HttpGet(baseUrl);
				log.info("request :::: "+request);
				HttpResponse response1 = client.execute(request);
				log.info("response1   :::: "+response1);
				if (response1 != null && response1.getEntity() != null) {
					HttpEntity entity = response1.getEntity();
					response = EntityUtils.toString(entity, UTF8);
				}
				log.info("Response::: " + response);
			}
		} catch (Exception e) {
			log.error("Error in processing http request ::: "+e);
		}
		return response;
	}
}*/