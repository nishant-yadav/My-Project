package com.aem.community.core.constants;

/**
 * The Class GlobalConstants.
 *
 * @author Siddharth
 */
public class GlobalConstants {

	/** The Constant IMAGE_NODE. */
	public static final String IMAGE_NODE = "image";

	/** The Constant FILE_REFERENCE. */
	public static final String FILE_REFERENCE = "fileReference";

	/** The Constant HOME_PAGE_URL. */
	public static final String HOME_PAGE_URL = "homePageUrl";

	/** The Constant HREF_LANG. */
	public static final String HREF_LANG = "hrefLang";

	/** The Constant LANGUAGE_CODE. */
	public static final String LANGUAGE_CODE = "languageCode";

	/** The Constant DATA_REGION. */
	public static final String DATA_REGION = "dataRegion";

	/** The Constant SHOW_IN_COUNTRY_SELECTOR. */
	public static final String SHOW_IN_COUNTRY_SELECTOR = "showInCountrySelector";

	/** The Constant TRUE. */
	public static final String TRUE = "true";

	/** The Constant LANGUAGR_MASTERS. */
	public static final String LANGUAGR_MASTERS = "Language Masters";

	/** The Constant REGION. */
	public static final String REGION = "region";

	/** The Constant BLANK. */
	public static final String BLANK = "";

	/** The Constant FALSE. */
	public static final String FALSE = "false";

	/** The Constant CONTENT_TYPE. */
	public static final String CONTENT_TYPE = "contentType";

	/** The Constant SLASH. */
	public static final String SLASH = "/";

	/** The Constant COLON_WITH_DOUBLE_SLASH. */
	public static final String COLON_WITH_DOUBLE_SLASH = "://";

	/** The Constant COLON. */
	public static final String COLON = ":";

	/** The Constant FOOTER. */
	public static final String FOOTER = "/footer";

	/** The Constant HEADER. */
	public static final String HEADER = "/header";

	/** The Constant DOT HTML. */
	public static final String DOT_HTML = ".html";

	/** The Constant CONTENT. */
	public static final String CONTENT = "/content";

	/** The Constant CONTENT DAM. */
	public static final String CONTENT_DAM = "/content/dam";

	/** The Constant HEAD_STLYES. */
	public static final String HEAD_STLYES = "/head-styles";

	/** The Constant HEAD_SCRIPTS. */
	public static final String HEAD_SCRIPTS = "/head-scripts";

	/** The Constant BODY_SCRIPTS. */
	public static final String BODY_SCRIPTS = "/body-scripts";

	/** The Constant FOOTER_COUNTRY_SELECTOR. */
	public static final String FOOTER_COUNTRY_SELECTOR = "/footer/country-selector";

	/** The Constant CONTENT_TYPE_JSON. */
	public static final String CONTENT_TYPE_JSON = "json";

	/** The Constant CONTENT_TYPE_JSONP. */
	public static final String CONTENT_TYPE_JSONP = "jsonp";

	/** The Constant CONTENT_TYPE_JS. */
	public static final String CONTENT_TYPE_JS = "js";

	/** The Constant CONTENT_TYPE_HTML. */
	public static final String CONTENT_TYPE_HTML = "html";

	/** The Constant FOOTER_JSON_PATH. */
	public static final String FOOTER_JSON_PATH = "jcr:content/root/footer.footerService.json";

	/** The Constant FOOTER_HTML_PATH. */
	public static final String FOOTER_HTML_PATH = "jcr:content/root/footer.html";

	/** The Constant HEADER_JSON_PATH. */
	public static final String HEADER_JSON_PATH = "jcr:content/root/header.headerService.json";

	/** The Constant HEADER_HTML_PATH. */
	public static final String HEADER_HTML_PATH = "jcr:content/root/header.html";

	/** The Constant HEAD_STYLES_PATH. */
	public static final String HEAD_STYLES_PATH = "jcr:content/root/head_styles.html";

	/** The Constant HEAD_SCRIPTS_PATH. */
	public static final String HEAD_SCRIPTS_PATH = "jcr:content/root/head_scripts.html";

	/** The Constant BODY_SCRIPTS_PATH. */
	public static final String BODY_SCRIPTS_PATH = "jcr:content/root/header.body-scripts.html";

	/** The Constant COUNTRY_SELECTOR_PATH. */
	public static final String COUNTRY_SELECTOR_PATH = "jcr:content/root/footer/countrySelector.html";

	/** The Constant COUNTRY_SELECTOR_JSON_PATH. */
	public static final String COUNTRY_SELECTOR_JSON_PATH = "jcr:content/root/footer/countrySelector.countryList.json";

	/** The Constant COUNTRY_SELECTOR_PATH. */
	public static final String JS_SERVLET_URL = "/bin/custom/jsservlet";

	/** The Constant HEADER_FOOTER_PATH. */
	public static final String JSONP_Servlet_URL = "/bin/custom/jsonpservlet";

	/** The Constant JS_URL. */
	public static final String JS_URL = "/etc.clientlibs/HPIT-AEM-GLOBALNAV/clientlibs-globalnav/clientlib-hfservice-js.js";

	/** The Constant NEW_URL. */
	public static final String NEW_URL = "newurl";

	/** The Constant APPLICATION_JSON. */
	public static final String APPLICATION_JSON = "application/json";

	/** The Constant UTF8. */
	public static final String UTF8 = "UTF-8";

	/** The Constant X_FORWARD_FOR. */
	public static final String X_FORWARD_FOR = "X-FORWARDED-FOR";

	/** The Constant PROXY_CLIENTIP. */
	public static final String PROXY_CLIENTIP = "Proxy-Client-IP";

	/** The Constant ANALYTICS_LINK_TYPE. */
	public static final String ANALYTICS_LINK_TYPE = "analyticsLinkType";

	/** The Constant ANALYTICS_LINK_PLACEMENT. */
	public static final String ANALYTICS_LINK_PLACEMENT = "analyticsLinkPlacement";

	/** The Constant ANALYTICS_LINK_ID. */
	public static final String ANALYTICS_LINK_ID = "analyticsLinkId";

	/** The Constant LOCAL_HOST. */
	public static final String LOCAL_HOST = "localhost";

	/** The Constant CONTENT_HPIT. */
	public static final String CONTENT_HPIT = "/content/HPIT-AEM-GLOBALNAV";

	/** The Constant YES. */
	public static final String YES = "yes";

	/** The Constant NO. */
	public static final String NO = "no";

	/** The Constant SHOW_SHOPPING_CART. */
	public static final String SHOW_SHOPPING_CART = "show_shopping_cart";

	/** The Constant HHO. */
	public static final String HHO = "hho";

	/** The Constant ENT. */
	public static final String ENT = "ent";

	/** The Constant SMB. */
	public static final String SMB = "smb";

	/** The Constant CC. */
	public static final String CC = "{@CC}";

	/** The Constant LL. */
	public static final String LL = "{@LL}";

	/** The Constant COUNTRY_CODE_US. */
	public static final String COUNTRY_CODE_US = "us";

	/** The Constant LANGUAGE_CODE_EN. */
	public static final String LANGUAGE_CODE_EN = "en";

}
