package com.aem.community.core.utils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aem.community.core.constants.GlobalConstants;

/**
 * The Class HeaderFooterUtility.
 */
public class HeaderFooterUtility {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(HeaderFooterUtility.class);

	/**
	 * Link check.
	 *
	 * @param url the url
	 * @param request the request
	 * @param getLanguageCode
	 * @param getCountryCode
	 * @return the string
	 */
	public static String linkCheck(String url, SlingHttpServletRequest request, String getCountryCode,
			String getLanguageCode) {
		if (url != null && url.startsWith(GlobalConstants.CONTENT)) {
			if (request.getServerName().equalsIgnoreCase(GlobalConstants.LOCAL_HOST)) {
				String newUrl = request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName()
						+ GlobalConstants.COLON + request.getServerPort() + url.concat(GlobalConstants.DOT_HTML);
				return replaceCCLL(newUrl, getCountryCode, getLanguageCode);
			} else {
				String newUrl = request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName()
						+ url.concat(GlobalConstants.DOT_HTML);
				return replaceCCLL(newUrl, getCountryCode, getLanguageCode);
			}
		} else
			return replaceCCLL(url, getCountryCode, getLanguageCode);
	}

	/**
	 * Dam link check.
	 *
	 * @param url the url
	 * @param request the request
	 * @return the string
	 */
	public static String damLinkCheck(String url, SlingHttpServletRequest request) {
		if (url != null && url.startsWith(GlobalConstants.CONTENT_DAM)) {
			if (request.getServerName().equalsIgnoreCase(GlobalConstants.LOCAL_HOST)) {
				return (request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName()
						+ GlobalConstants.COLON + request.getServerPort() + url);
			} else {
				return (request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName() + url);
			}

		} else
			return url;
	}

	/**
	 * Country link check.
	 *
	 * @param url the url
	 * @param request the request
	 * @return the string
	 */
	public static String countryLinkCheck(String url, SlingHttpServletRequest request) {
		if (url != null) {
			if (request.getServerName().equalsIgnoreCase(GlobalConstants.LOCAL_HOST)) {
				return request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName()
						+ GlobalConstants.COLON + request.getServerPort() + GlobalConstants.CONTENT_HPIT + url;
			} else {
				return request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH + request.getServerName() + url;
			}
		}
		return url;
	}

	/**
	 * Replace CCLL.
	 *
	 * @param url the url
	 * @param getLanguageCode
	 * @param getCountryCode
	 * @return the string
	 */
	public static String replaceCCLL(String url, String getCountryCode, String getLanguageCode) {
		LOGGER.debug("Authored URL is {}", url);
		if (getCountryCode == null) {
			getCountryCode = GlobalConstants.COUNTRY_CODE_US;
		}
		if (getLanguageCode == null) {
			getLanguageCode = GlobalConstants.LANGUAGE_CODE_EN;
		}
		String newUrl = "";
		if (url != null) {

			if (url.contains(GlobalConstants.CC)) {
				newUrl = url.replace(GlobalConstants.CC, getCountryCode);
				LOGGER.debug("Removed {} from URL & new URL {}", GlobalConstants.CC, newUrl);

				if (newUrl.contains(GlobalConstants.LL)) {
					url = newUrl.replace(GlobalConstants.LL, getLanguageCode);
					LOGGER.debug("Removed {} from URL & new URL {}", GlobalConstants.LL, url);
				}
			}
		}
		return url;
	}

}
