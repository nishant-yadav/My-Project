package com.aem.community.core.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletException;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aem.community.core.constants.GlobalConstants;

/**
 * The Class CountrySelectorServlet.
 */
@SuppressWarnings("serial")
@SlingServlet(paths = "/bin/custom/jsonpservlet")
public class HeaderFooterJSONPServlet extends SlingAllMethodsServlet {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(HeaderFooterJSONPServlet.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.sling.api.servlets.SlingAllMethodsServlet#doPost(org.apache.
	 * sling.api.SlingHttpServletRequest,
	 * org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		
		String newurl = GlobalConstants.BLANK;
		String content = GlobalConstants.BLANK;

		if (request.getAttribute("absolute_cs_url") != null) {
			newurl = request.getAttribute("absolute_cs_url").toString();
			content = "callback({\"country-selector\":\"" + decodeUnicode(StringEscapeUtils.escapeJavaScript(getContentFromURL(newurl))) + "\"})";
			
		} else if(request.getAttribute("absolute_header_url") != null){
			newurl = request.getAttribute("absolute_header_url").toString();
			content = "callback({\"header\":\"" + decodeUnicode(StringEscapeUtils.escapeJavaScript(getContentFromURL(newurl))) + "\"})";
			
		}else if(request.getAttribute("absolute_footer_url") != null){
			newurl = request.getAttribute("absolute_footer_url").toString();
			content = "callback({\"footer\":\"" + decodeUnicode(StringEscapeUtils.escapeJavaScript(getContentFromURL(newurl))) + "\"})";
			
		} else if(request.getAttribute("headscript_url")!=null){
		
			String hadescript_content = getContentFromURL((String) request.getAttribute("headscript_url"));
			String footer_content = getContentFromURL((String) request.getAttribute("footer_url"));
			String headstyles_content = getContentFromURL((String) request.getAttribute("headstyles_url"));
			String bodyscripts_content = getContentFromURL((String) request.getAttribute("bodyscripts_url"));
			String header_content = getContentFromURL((String) request.getAttribute("header_url"));

			content = "callback({\"head-scripts\":\"" + StringEscapeUtils.escapeJavaScript(hadescript_content) + "\","
								+  "\"footer\":\"" + decodeUnicode(StringEscapeUtils.escapeJavaScript(footer_content)) + "\","
								+  "\"head-styles\":\"" + StringEscapeUtils.escapeJavaScript(headstyles_content) + "\","
								+  "\"body-scripts\":\"" + StringEscapeUtils.escapeJavaScript(bodyscripts_content) + "\","
								+  "\"header\":\"" + decodeUnicode(StringEscapeUtils.escapeJavaScript(header_content)) + "\""
								+ "})";
		
		
		}else {
			LOGGER.error("Invalid URL");
			response.getOutputStream().println("Invalid URL");
		}
		
		LOGGER.info("New URL in CountryServlet {}", newurl);
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/javascript; charset=UTF-8");
		response.getWriter().write(content);
	}
	
	public synchronized String getContentFromURL(String url){
		String url_content = GlobalConstants.BLANK;
			try {
					String parseLine;
					URL URL = new URL(url);
					URLConnection conn = URL.openConnection();
					BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"));
			
					while ((parseLine = br.readLine()) != null) {
						url_content = url_content + parseLine;
					}
					br.close();
					
				} catch (MalformedURLException me) {
					LOGGER.error("MalformedURLException - ", me.getMessage());
		
				} catch (IOException ioe) {
					LOGGER.error("IOException - " + ioe.getMessage());
				} catch(Exception e){
					LOGGER.error("Exception - " + e.getMessage());
				}
		return url_content;
	}
	
	public String decodeUnicode(String escaped) {
		if(escaped.indexOf("\\u")==-1)
	        return escaped;

	    String processed="";

	    int position=escaped.indexOf("\\u");
	    while(position!=-1) {
	        if(position!=0)
	            processed+=escaped.substring(0,position);
	        String token=escaped.substring(position+2,position+6);
	        escaped=escaped.substring(position+6);
	        processed+=(char)Integer.parseInt(token,16);
	        position=escaped.indexOf("\\u");
	    }
	    processed+=escaped;

	    return processed;
	}
	
	
}
