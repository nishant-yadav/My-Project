package com.aem.community.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.ExporterOption;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

@Model(adaptables = Resource.class, resourceType = { "/content/AEMMaven13/jcr:content" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = "jackson", extensions = "json", selector = "training", options = { @ExporterOption(name = "SerializationFeature.WRITE_DATES_AS_TIMESTAMPS", value = "true") })
public class ModelComponent {
	
/*	@Self
	private Resource resource;
	
	@Self
	private ResourceResolver resourceResolver;

	@Inject
	String title;

	@Inject
	String heading;

	@Inject
	String buttonLabel;

	@Inject
	String buttonLinkTo;

	@Inject
	String fileReference;

	@Inject
	@Named("sling:resourceType")
	String slingResourceType;
	
	private Page page;
	
	@PostConstruct
	private String init() {
		page = resourceResolver.adaptTo(PageManager.class).getContainingPage(resource);
		return page.getPath();
	}

	public String getHeading() {
		return heading;
	}

	public String getButtonLabel() {
		return buttonLabel;
	}

	public String getButtonLinkTo() {
		return buttonLinkTo;
	}

	public String getSlingResourceType() {
		return slingResourceType;
	}

	public String getTitle() {
		return title;
	}

	public String getFileReference() {
		return fileReference;
	}*/
	
	@Self
	private Resource resource;
	
	@Self
	private ResourceResolver resourceResolver;

	@Inject
	@Named("sling:resourceType")
	String slingResourceType;
	
	@Inject
	@Named("jcr:title")
	String title;
	
	@Inject
	@Named("redirectTarget")
	String redirectTarget;
	
	@Inject
	@Named("sling:redirectStatus")
	Long redirectStatus;
	
	@Inject
	String heading;
	
	private Page page;
	
	@PostConstruct
	private String init() {
		page = resourceResolver.adaptTo(PageManager.class).getContainingPage(resource);
		heading = "FROM MODEL";
		return heading+"\t"+page.getPath();
	}
	
	public String getSlingResourceType() {
		return slingResourceType;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getRedirectTarget() {
		return redirectTarget;
	}
	
	public Long getRedirectStatus() {
		return redirectStatus;
	}
	
	public String getHeading() {
		return heading;
	}

}
