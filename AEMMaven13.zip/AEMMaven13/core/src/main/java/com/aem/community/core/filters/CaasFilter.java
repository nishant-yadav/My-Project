package com.aem.community.core.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.servlets.annotations.SlingServletFilter;
import org.apache.sling.servlets.annotations.SlingServletFilterScope;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aem.community.core.constants.GlobalConstants;

/**
 * The Class CaasFilter.
 */
@Component(service = Filter.class, immediate = true)
@Designate(ocd = CaasFilter.CaasFilterConfig.class, factory = true)
@SlingServletFilter(scope = { SlingServletFilterScope.REQUEST }, pattern = "/caas/header-footer/.*", methods = { "GET",
		"HEAD" })
public class CaasFilter implements Filter {

	/**
	 * The Interface CaasFilterConfig.
	 */
	@ObjectClassDefinition(name = "Caas Filter Configuration", description = "Global Header Footer Caas Filter Configuration")
	public @interface CaasFilterConfig {

		/**
		 * Content path.
		 *
		 * @return the string
		 */
		@AttributeDefinition(name = "Content Path", description = "Content Path", type = AttributeType.STRING)
		String contentPath() default "/content/HPIT-AEM-GLOBALNAV/";

		/**
		 * Page path.
		 *
		 * @return the string
		 */
		@AttributeDefinition(name = "Page Path", description = "Path Path", type = AttributeType.STRING)
		String pagePath() default "/globalhf/";

		/**
		 * Hho page path.
		 *
		 * @return the string
		 */
		@AttributeDefinition(name = "HHO Page Path", description = "HHO Path Path", type = AttributeType.STRING)
		String hhoPagePath() default "/hhoglobalhf/";

		/**
		 * Ent page path.
		 *
		 * @return the string
		 */
		@AttributeDefinition(name = "ENT Page Path", description = "ENT Path Path", type = AttributeType.STRING)
		String entPagePath() default "/entglobalhf/";

		/**
		 * Smb page path.
		 *
		 * @return the string
		 */
		@AttributeDefinition(name = "SMB Page Path", description = "SMB Path Path", type = AttributeType.STRING)
		String smbPagePath() default "/smbglobalhf/";

	}

	/** The config. */
	private CaasFilterConfig config;

	/**
	 * Activate.
	 *
	 * @param config
	 *            the config
	 */
	@Activate
	public void activate(CaasFilterConfig config) {
		this.config = config;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CaasFilter.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		final SlingHttpServletResponse slingResponse = (SlingHttpServletResponse) response;
		final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;

		String pathinfo = slingRequest.getPathInfo();
		String suffix = slingRequest.getRequestPathInfo().getSuffix();
		String contentType = slingRequest.getParameter(GlobalConstants.CONTENT_TYPE);

		LOGGER.debug("CAAS Filter Path Info - " + pathinfo);
		LOGGER.debug("Suffix - " + suffix);
		LOGGER.debug("Content Type - " + contentType);
		String[] pathParts = pathinfo.split(GlobalConstants.SLASH);
		try {
			if (pathParts.length > 4) {
				String country = pathParts[3]; // country
				String language = pathParts[4]; // language

				String newurl = GlobalConstants.BLANK;

				response.setCharacterEncoding("UTF-8");
				response.setContentType("text/html");
				String requestPagePath = config.pagePath();

				if (slingRequest.getPathInfo().toLowerCase().contains(GlobalConstants.HHO)) {
					LOGGER.debug("Inside hho condition & hho page path is {}", config.hhoPagePath());
					requestPagePath = config.hhoPagePath();
				}
				if (slingRequest.getPathInfo().toLowerCase().contains(GlobalConstants.ENT)) {
					LOGGER.debug("Inside ent condition & ent page path is {}", config.entPagePath());
					requestPagePath = config.entPagePath();
				}
				if (slingRequest.getPathInfo().toLowerCase().contains(GlobalConstants.SMB)) {
					LOGGER.debug("Inside smb condition & smb page path is {}", config.smbPagePath());
					requestPagePath = config.smbPagePath();
				}

				LOGGER.debug("Page path is {}", requestPagePath);

				String headscript_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.HEAD_SCRIPTS_PATH;

				String footer_url = config.contentPath() + country + GlobalConstants.SLASH + language + requestPagePath
						+ GlobalConstants.FOOTER_HTML_PATH;

				String headstyles_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.HEAD_STYLES_PATH;

				String bodyscripts_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.BODY_SCRIPTS_PATH;

				String header_url = config.contentPath() + country + GlobalConstants.SLASH + language + requestPagePath
						+ GlobalConstants.HEADER_HTML_PATH;

				String footer_json_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.FOOTER_JSON_PATH;

				String header_json_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.HEADER_JSON_PATH;

				String country_selector_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.COUNTRY_SELECTOR_PATH;

				String country_selector_json_url = config.contentPath() + country + GlobalConstants.SLASH + language
						+ requestPagePath + GlobalConstants.COUNTRY_SELECTOR_JSON_PATH;

				String absolute_url = request.getScheme() + GlobalConstants.COLON_WITH_DOUBLE_SLASH
						+ request.getServerName() + GlobalConstants.COLON + request.getServerPort();

				String js_url = GlobalConstants.JS_URL;

				if ((suffix == null || suffix.equals(GlobalConstants.BLANK))
						&& (contentType != null && contentType.equals(GlobalConstants.CONTENT_TYPE_JS))) {

					request.setAttribute("headstyles_url", absolute_url + headstyles_url);
					request.setAttribute("headscript_url", absolute_url + headscript_url);
					request.setAttribute("footer_url", absolute_url + footer_url);
					request.setAttribute("header_url", absolute_url + header_url);
					request.setAttribute("bodyscripts_url", absolute_url + bodyscripts_url);
					request.setAttribute("js_url", absolute_url + js_url);

					newurl = GlobalConstants.JS_SERVLET_URL;

				} else if ((suffix == null || suffix.equals(GlobalConstants.BLANK))
						&& (contentType != null && contentType.equals(GlobalConstants.CONTENT_TYPE_JSONP))) {

					request.setAttribute("headstyles_url", absolute_url + headstyles_url);
					request.setAttribute("headscript_url", absolute_url + headscript_url);
					request.setAttribute("footer_url", absolute_url + footer_url);
					request.setAttribute("header_url", absolute_url + header_url);
					request.setAttribute("bodyscripts_url", absolute_url + bodyscripts_url);

					newurl = GlobalConstants.JSONP_Servlet_URL;

				} else if (suffix.equals(GlobalConstants.FOOTER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSON)) {
					newurl = footer_json_url;

				} else if (suffix.equals(GlobalConstants.FOOTER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_HTML)) {
					newurl = footer_url;

				} else if (suffix.equals(GlobalConstants.FOOTER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSONP)) {
					String absolute_footer_url = absolute_url + footer_url;
					request.setAttribute("absolute_footer_url", absolute_footer_url);

					newurl = GlobalConstants.JSONP_Servlet_URL;

				} else if (suffix.equals(GlobalConstants.FOOTER)) {
					newurl = footer_url;

				} else if (suffix.equals(GlobalConstants.HEADER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSON)) {
					newurl = header_json_url;

				} else if (suffix.equals(GlobalConstants.HEADER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_HTML)) {
					newurl = header_url;

				} else if (suffix.equals(GlobalConstants.HEADER) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSONP)) {
					String absolute_header_url = absolute_url + header_url;
					request.setAttribute("absolute_header_url", absolute_header_url);

					newurl = GlobalConstants.JSONP_Servlet_URL;

				} else if (suffix.equals(GlobalConstants.HEADER)) {
					newurl = header_url;

				} else if (suffix.equals(GlobalConstants.HEAD_STLYES)) {
					response.setContentType("application/xhtml+xml");
					newurl = headstyles_url;

				} else if (suffix.equals(GlobalConstants.HEAD_SCRIPTS)) {
					response.setContentType("application/xhtml+xml");
					newurl = headscript_url;

				} else if (suffix.equals(GlobalConstants.BODY_SCRIPTS)) {
					request.setAttribute("bodyscriptsjs_url", absolute_url + bodyscripts_url);
					newurl = GlobalConstants.JS_SERVLET_URL;

				} else if (suffix.equals(GlobalConstants.FOOTER_COUNTRY_SELECTOR) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSONP)) {
					String absolute_cs_url = absolute_url + country_selector_url;
					request.setAttribute("absolute_cs_url", absolute_cs_url);

					newurl = GlobalConstants.JSONP_Servlet_URL;

				} else if (suffix.equals(GlobalConstants.FOOTER_COUNTRY_SELECTOR) && contentType != null
						&& contentType.equals(GlobalConstants.CONTENT_TYPE_JSON)) {
					newurl = country_selector_json_url;

				} else if (suffix.equals(GlobalConstants.FOOTER_COUNTRY_SELECTOR)) {
					newurl = country_selector_url;
				}
				LOGGER.debug("New Url from Caas Filter {}", newurl);
				request.getRequestDispatcher(newurl).include(request, response);
				return;

			} else {
				slingResponse.getWriter().println("Wrong URL");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
	}

}
