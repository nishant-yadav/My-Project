package com.aem.community.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

/**
 * The Class VersionModel.
 * 
 *  @author Nishant
 */
@Model(adaptables = Resource.class, resourceType = {
"HPIT-AEM-GLOBALNAV/components/content/head-styles", 
"HPIT-AEM-GLOBALNAV/components/content/head-scripts", 
"HPIT-AEM-GLOBALNAV/components/content/body-scripts" }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class VersionModel {

	@Inject
	private String version;
	
	@Inject
	private String metaName;

	public String getVersion() {
		return version;
	}

	public String getMetaName() {
		return metaName;
	}

}
