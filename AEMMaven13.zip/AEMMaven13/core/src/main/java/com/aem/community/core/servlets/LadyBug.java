package com.aem.community.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aem.community.core.constants.GlobalConstants;

/**
 * The Class LadyBug.
 * @author Varun
 */
@SuppressWarnings("serial")
@SlingServlet(paths = "/bin/custom/ladyBug")
public class LadyBug extends SlingSafeMethodsServlet {

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(LadyBug.class);
	
	/** The Constant patterns. */
	private static final List<Pattern> patterns = new ArrayList<Pattern>();
	
	/** The ip exist. */
	private Boolean ipExist;

	/* (non-Javadoc)
	 * @see org.apache.sling.api.servlets.SlingSafeMethodsServlet#doGet(org.apache.sling.api.SlingHttpServletRequest, org.apache.sling.api.SlingHttpServletResponse)
	 */
	@Override
	protected void doGet(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
			throws ServletException, IOException {
		LOG.info("LadyBug Servlet Do Get Method");
		try {

			String cookieValue;
			jspInit();
			LADYBUG_JS(req);
			if (ipExist)
				cookieValue = "1";
			else
				cookieValue = "0";

			Map<String, String> data = new HashMap<>();
			data.put("ipExist", cookieValue);
			String json = cookieValue;

			resp.setContentType(GlobalConstants.APPLICATION_JSON);
			resp.setCharacterEncoding(GlobalConstants.UTF8);
			resp.getWriter().write(json);

		} catch (Exception e) {
			LOG.error("LadyBug Get Method Servlet-->", e);
		}

	}

	/**
	 * Ladybug js.
	 *
	 * @param request the request
	 * @return the string
	 */
	public String LADYBUG_JS(SlingHttpServletRequest request) {
		try {
			String ipAddr = request.getRemoteAddr();
			if (ipAddr == null)
				ipAddr = "";
			ipExist = isInternalNetworkIp(ipAddr);
			String ipAddrXF = request.getHeader(GlobalConstants.X_FORWARD_FOR);
			String ipAddrPC = request.getHeader(GlobalConstants.PROXY_CLIENTIP);

			if (ipAddrXF == null || ipAddrXF.length() < 7 || ipAddrXF.indexOf("<") == 0) {
				ipAddrXF = "";
			}
			if (ipAddrPC == null || ipAddrPC.length() < 7 || ipAddrPC.indexOf("<") == 0) {
				ipAddrPC = "";
			}

			String[] arrXF = ipAddrXF.split(",");
			String[] arrPC = ipAddrPC.split(",");

			// Keep the first ip if we got an array
			if (arrXF != null && arrXF.length >= 1 && arrXF[0] != null) {
				ipAddrXF = arrXF[0].trim();
			}
			if (arrPC != null && arrPC.length >= 1 && arrPC[0] != null) {
				ipAddrPC = arrPC[0].trim();
			}

			if (!"".equals(ipAddrPC)) {
				ipAddr = ipAddrPC;
			}
			if (!"".equals(ipAddrXF)) {
				ipAddr = ipAddrXF;
			}
			ipAddr = ipAddr.trim();
			/* ------------------------------------ */

			/*
			 * if (isInternalNetworkIp(ipAddr)) { return ladybug(true, ipAddr);
			 * }
			 */

			return ipAddr;
		} catch (Exception e) {
			LOG.error("LadyBug JS Method-->" + e);
		}
		LOG.info("Out of Try-Catch BLock");
		return "true";
	}

	/**
	 * Jsp init.
	 */
	public void jspInit() {
		// Previous patterns
		// ipAddr.startsWith("15.")
		patterns.add(Pattern.compile(
				"^15\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// ipAddr.startsWith("16.")
		patterns.add(Pattern.compile(
				"^16\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// ipAddr.startsWith("161.114.")
		patterns.add(Pattern.compile(
				"^161\\.114\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// ipAddr.startsWith("148.94.")
		patterns.add(Pattern.compile(
				"^148\\.94\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// ipAddr.startsWith("192.6.1.") || ipAddr.startsWith("192.6.2.")
		patterns.add(Pattern.compile("^192\\.6\\.[1-2]\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));

		// New patterns
		// 192.56.* i.e.,192.56.0.0 to 192.56.255.255
		patterns.add(Pattern.compile(
				"^192\\.56\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 112.80.60.4
		patterns.add(Pattern.compile("^112\\.80\\.60\\.4$"));
		// 165.225.28.0/23 i.e., 165.225.28.0 to 165.225.29.225
		patterns.add(Pattern.compile("^165\\.225\\.(2[8-9])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.88.0/24
		patterns.add(Pattern.compile("^165\\.225\\.88\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.24.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(2[4-5])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.16.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(1[6-7])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.86.0/24
		patterns.add(Pattern.compile("^165\\.225\\.86\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 213.52.102.0/24
		patterns.add(Pattern.compile("^213\\.52\\.102\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.76.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(7[6-7])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 94.188.131.0/25
		patterns.add(Pattern.compile("^94\\.188\\.131\\.([0-9]|[1-9][0-9]|1([0-1][0-9]|2[0-7]))$"));
		// 165.225.84.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(8[4-5])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));

		// 104.129.206.0/23
		patterns.add(
				Pattern.compile("^104\\.129\\.(2(0[6-7]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.0.0/23
		patterns.add(Pattern.compile("^165\\.225\\.([0-1])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.34.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(3[4-5])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 104.129.202.0/23
		patterns.add(
				Pattern.compile("^104\\.129\\.(2(0[2-3]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.50.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(5[0-1])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.36.0/23
		patterns.add(Pattern.compile("^165\\.225\\.(3[6-7])\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.48.0/24
		patterns.add(Pattern.compile("^165\\.225\\.48\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));

		// 165.225.116.0/23
		patterns.add(
				Pattern.compile("^165\\.225\\.(1(1[6-7]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.106.0/24
		patterns.add(Pattern.compile("^165\\.225\\.106\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 58.220.95.0/24
		patterns.add(Pattern.compile("^58\\.220\\.95\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.112.0/23
		patterns.add(
				Pattern.compile("^165\\.225\\.(1(1[2-3]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.114.0/23
		patterns.add(
				Pattern.compile("^165\\.225\\.(1(1[4-5]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));
		// 165.225.110.0/23
		patterns.add(
				Pattern.compile("^165\\.225\\.(1(1[0-1]))\\.([0-9]|[1-9][0-9]|1([0-9][0-9])|2([0-4][0-9]|5[0-5]))$"));

		// 172.20.133.6/
		patterns.add(Pattern.compile("^172\\.20\\.133\\.6$"));

		// 185.46.212.88/98
		patterns.add(Pattern.compile("^185\\.46\\.212\\.(8[8-9]|9[0-8])$"));
	}

	/**
	 * Checks if is internal network ip.
	 *
	 * @param ipAddr the ip addr
	 * @return true, if is internal network ip
	 */
	private static boolean isInternalNetworkIp(String ipAddr) {
		if (null != ipAddr && !ipAddr.equals(GlobalConstants.BLANK)) {
			for (Pattern ptrn : patterns) {
				if (ptrn.matcher(ipAddr).matches()) {
					return true;
				}

			}
		}
		return false;
	}
}
