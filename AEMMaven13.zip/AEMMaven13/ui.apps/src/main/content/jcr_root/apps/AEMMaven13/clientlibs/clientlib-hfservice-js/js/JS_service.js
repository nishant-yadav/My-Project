window.CAAS_HF_CLIENTSIDE=true;
var HP=window.HP||{};
var loaderScriptElement;

HP.caasDomain=(function()
{
	var scripts=document.getElementsByTagName('script'),src,link,domain;
	
	for(var a=0;a<scripts.length;a++)
		{
			src=scripts[a].src.toLowerCase();
			if(src.indexOf('/caas-loader-')>0||src.indexOf('/caas/header-footer/')>0)
			{	link=src.split('/');
				loaderScriptElement=scripts[a];
				break;
			}
		}
	domain=link[0]+'//'+link[2]+'/';
	domain=domain.replace("www.www8-hp.com","www8.hp.com");
	return domain;
})();

var initHF=(function($)
{

	var defaultTargets={'head-styles':'head','head-scripts':'head','header':'#header','body-scripts':'body','footer':'#footer','birdseed':'#birdseed'},defaultClasses={'header':'header','footer':'footer','birdseed':'birdseed'},
	HEAD_STYLES='head-styles',HEAD_SCRIPTS='head-scripts',targets,styleClasses;

	var ltIE9=/MSIE\s+[6-8]./i.test(navigator.userAgent);

	var isIE=navigator.userAgent.toUpperCase().indexOf("MSIE")!=-1;

	var inlineScripts=ltIE9?'':$();
	
	$.cachedScript=function(url,options)
	{
		/*options=$.extend(options||{},{dataType:"script",cache:true,url:url});
		return $.ajax(options);*/
	};

	function loadScripts(scriptList,callback)
	{$.when($.cachedScript(scriptList.shift())).then(function()
		{if(scriptList.length==0)
			{callback();
			if(typeof console!="undefined")console.log('initHF: scripts loading is done');
		}else
			{loadScripts(scriptList,callback);
		}});
	};
	
	function updateDom(data)
	{
		var scriptRe=/<script[\s\S]*?\/script>/gim,element=$('<div/>'),targetEl,styleClass;
		$.each(data,function(key,value)
			{targetEl=$(targets[key]);
			
		if(ltIE9){
			value=value.replace(scriptRe,function(str)
				{inlineScripts+=str;
					return'';
				});
			targetEl.append(value);
		}else{
			element.get(0).innerHTML=value;
			inlineScripts=inlineScripts.add(element.find('script').detach());
			targetEl.append(element.children());
		}
		
		styleClass=styleClasses[key];
		
		if(styleClass){
			targetEl.addClass(styleClass);
		}});
	};
	
	function updatePage(data)	
	{
		var re=/(src|href)=('|")(http[s]?:)?(\/\/.*?)('|")/gim;
		var headStyles=data[HEAD_STYLES];
		var cssUrl;
		
		if(headStyles)
		{
			var theHead=$(targets[HEAD_STYLES]).append(headStyles);
			
			if(isIE)
			{
				$("link",theHead).each(function(index,elem)
					{if(elem.href&&elem.href.indexOf("-fontface-")>0)elem.href=elem.href;
				});
			}
			
			cssUrl=/"([^"]*hf-v\d.\d.css)"/.exec(data[HEAD_STYLES]);
			if(cssUrl)
				cssUrl=cssUrl[1];
			delete data[HEAD_STYLES];
		}

		var link,scripts=[],headScripts=data[HEAD_SCRIPTS];
		
		if(headScripts)
		{
			$(targets[HEAD_SCRIPTS]).append(headScripts);
			re.lastIndex=0;
			
			while((link=re.exec(headScripts))!=null)
			{
				scripts.push(link[3]+link[4]);
			}
			delete data[HEAD_SCRIPTS];
		}
				
		loadScripts(scripts,function()
		{
			var $body=$('body');
			if(cssUrl)
			{
				var img=document.createElement('img');
				img.onerror=function()
				{
					updateDom(data);
					$body.append(inlineScripts);
					$body.triggerHandler('HP.HF.READY');
				};
				img.src=cssUrl;
			}else{
				updateDom(data);
				$body.append(inlineScripts);
				$body.triggerHandler('HP.HF.READY');
			}});
	};
	
	return function(urlOrData,customTargets,classes){
		$(function()
			{
				targets=$.extend(defaultTargets,customTargets);
				styleClasses=$.extend(defaultClasses,classes);
				
				if(typeof urlOrData=='string')
				{
					$.ajax(
						{dataType:"jsonp",url:urlOrData,jsonpCallback:'cb',cache:true}).done(updatePage);
				}else{
					updatePage(urlOrData);
				}});
	};
})(can.$);

function hfwsGetHeaderFooter(options)
{
	var default_opt={'cc':'us','ll':'en','headerDiv':'header_hfws','footerDiv':'footer_hfws','version':'latest','wafdebug':''};
	var minigateway_rdr=
	{'al.sq':'ie.en','ba.bs':'hr.hr','dz.fr':'emea_africa.fr','ke.en':'emea_africa.en','ks.sq':'ie.en','ma.fr':'emea_africa.fr','md.ro':'ro.ro','mk.mk':'ie.en','mt.en':'ie.en','ng.en':'emea_africa.en','tn.fr':'emea_africa.fr','pk.en':'my.en','bd.en':'my.en','lk.en':'my.en','ao.pt':'emea_africa.en'};

	var defaultTargets={'head-styles':'head','head-scripts':'head','header':'#header','body-scripts':'body','footer':'#footer','birdseed':'#birdseed'};
	var defaultClasses={'header':'header','footer':'footer','birdseed':'birdseed'};

	for(var index in default_opt)
	{
		if(typeof options[index]=="undefined")
			options[index]=default_opt[index];
	}

	var lcl=options['cc']+'.'+options['ll'];

	if(lcl in minigateway_rdr)
	{
		var lcl_redir=minigateway_rdr[lcl];
		options['cc']=lcl_redir.split('.')[0];
		options['ll']=lcl_redir.split('.')[1];
		lcl_redir=lcl;
	}

	var targets=defaultTargets;
	targets['header']='#'+options['headerDiv'];
	targets['footer']='#'+options['footerDiv'];

	var hfwsURL=HP.caasDomain+'caas/header-footer/'+options['cc']+'/'+options['ll']+'/default/latest.r?contentType=jsonp';

	if((HP.caasDomain.indexOf('https')!=-1)&&(navigator.userAgent.toLowerCase().indexOf("msie")!=-1))
	{
		hfwsURL=hfwsURL+'&rndm='+(new Date()).getTime();
	}
	initHF(hfwsURL,targets,defaultClasses);
}