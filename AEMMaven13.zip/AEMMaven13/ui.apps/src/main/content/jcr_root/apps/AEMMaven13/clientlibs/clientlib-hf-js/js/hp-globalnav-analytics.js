(function () {

	var init = function () {
		loadPageViewAnalytics();
		loadEventAnalytics();
	}

	var loadPageViewAnalytics = function () {
		var analyticsObj = { "event": "e_pageView" },
			pageViewKeys = {
				"pageNameL5": "page_level",
				"pageNameL6": "product_type",
				"pageNameL7": "family",
				"pageNameL8": "simple_title"
			},
			tagContent = '';

		for (var tagName in pageViewKeys) {
			tagContent = getMetaTagContent(pageViewKeys[tagName]);
			if (tagContent) {
				analyticsObj[tagName] = tagContent;
			}
		}

		if (dataLayer && Array.isArray(dataLayer)) {
			dataLayer.push(analyticsObj);
		}
	}

	var loadEventAnalytics = function () {
		var elements = document.querySelectorAll('[data-link-id], [data-link-type], [data-link-placement]');
		for (var i = 0; i < elements.length; i++) {
			elements[i].addEventListener('click', function () {
				var elementData = this.dataset;
				var isDataAvailable = elementData.linkType && elementData.linkId && elementData.linkPlacement;
				if (dataLayer && Array.isArray(dataLayer) && isDataAvailable) {
					elementData.linkType === 'e_document' ? 
					dataLayer.push ({
						"event": elementData.linkType,
						"documentAction": 'view',
						"documentID": elementData.linkId,
						"documentType": elementData.linkPlacement
					}):
					dataLayer.push({
						"event": elementData.linkType ? elementData.linkType : '',
						"linkPlacement": elementData.linkPlacement ? elementData.linkPlacement : '',
						"linkID": elementData.linkId ? elementData.linkId : ''
					});
				}
			});
		}
	}

	var getMetaTagContent = function (name) {
		var tagConent = document.head.querySelector("meta[name~=" + name + "][content]");
		return tagConent ? tagConent.content : '';
	}

	document.addEventListener('DOMContentLoaded', function () {
		init();
	});

}());