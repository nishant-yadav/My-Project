$(document).ready(function () {

	$('.wpr-side-nav').css({
		"height":window.innerHeight
	});
	
	$('.wpr-side-nav-submenu').css({
		"height":window.innerHeight
	});

	$(window).resize(function () {
		if(window.innerHeight!=screen_size){
			$('.wpr-side-nav').css({
				"height":window.innerHeight
			});
			$('.wpr-side-nav-submenu').css({
				"height":window.innerHeight
			});
		}
	screen_height = window.innerHeight;
	});

	set_screensize();
	function set_screensize() {
		screen_size = $(window).width();
		return screen_size;
	}

	var country_flag = $('html').is(':lang(ar)');
	if(country_flag){

		$('.wpr-logo-header-holder').css({
			"left": "unset",
			"right": "33px"
		});
		
		$('.wpr-logo-holder').css({
			"left": "unset",
			"right": "20px"
		});
		
		$('.wpr-link-container').css({
			"margin-right": "60px",
			"margin-left": "0px"
		});
		$('.navbar-header-links').css({
			"margin-right": "0px",
			"margin-left": "40px"
		});
		$('.tab-search').css({
			"text-align": "right",
			"margin-left":"0px",
			"margin-right":"20px"
		});
		
		$('.wpr-close-submenu-desk').css({
			"left":"15px",
			"right": "unset"
		});

		$('.wpr-submenu-container').css({
			"margin-left":"30px",
			"margin-right":"0px"
		});

		$('.wpr-submenu-item').css({
			"margin-left":"30px",
			"margin-right":"0px"
		});

		if(set_screensize()>=1450){
			$('.wpr-dropdown-nav').css({
				"padding": "30px 80px 60px 30px",
			});
		}else {
			$('.wpr-dropdown-nav').css({
				"padding": "30px 30px 60px 0px",
			});
		}

		$('.wpr-side-nav').css({
			"left":"0",
			"right": "unset",
			"direction":"ltr"
		});
		$('.wpr-side-nav-submenu').css({
			"left":"0",
			"right": "unset",
		});

		$('.header-submenu').css({
			"right":"30px",
			"left": "unset",
		});

		$('.wpr-submenu-item-mobile').children('.wpr-submenu-heading').children('.row').css({
			"right":"30px",
			"left": "unset",
		});
		
		$('.sub-submenu-data-mobile').children('ul').children('a').children('.Rectangle-505').children('.row').css({
			"right":"40px",
			"left": "unset",
		});	
		
}
	$(window).resize(function () {
		if(country_flag){

		if(set_screensize()>=1450){
			$('.wpr-dropdown-nav').css({
				"padding": "30px 80px 60px 30px",
			});
		}else {
			$('.wpr-dropdown-nav').css({
				"padding": "30px 30px 60px 0px",
			});
		}
	}

	});

	//NAVIGATION JS STARTS
	const main_menu = $(".wpr-navbar-container");
	const level_one_menu = $(".wpr-side-nav");
	const level_two_menu = $(".wpr-side-nav-submenu");
	const tab_drop_container = $(".wpr-dropdown-container");
	const all_nav_submenu = $(".wpr-dropdown-nav");
	const navbar_links_tab_underline = $(".navbar-header-links");
	connected_submenu_obj = '';

	offset = 0;

	// open menu mobile
	$(".wpr-menu-icon").click(function () {
		$('body').css({
			"overflow": "hidden",
			"position": "fixed"
		});
		main_menu.fadeIn(300,"linear").addClass("wpr-show");
		level_one_menu.fadeIn(300,"linear").addClass("wpr-show");
		$(".wpr-search-container").fadeOut(0).removeClass("wpr-show");
		$('.createList').remove();
		$(".clear-search").css('display', 'none');
		$('.arrows_search_mobile').fadeOut(0).removeClass("wpr-show");
		$('.wpr-block-title').remove();
		$('.createList_tab').remove();
		$('.createList_mobile').remove();
		$(".search-bar").val("");
	});
	
	//open menu by enter key
	$(".wpr-menu-icon").keydown(function (e) {
		if (e.which == 13) {
			$('body').css({
				"overflow": "hidden",
				"position": "fixed"
			});
			main_menu.fadeIn(300,"linear").addClass("wpr-show");
			level_one_menu.fadeIn(300,"linear").addClass("wpr-show");
			$(".wpr-search-container").fadeOut(0).removeClass("wpr-show");
			$('.createList').remove();
			$(".clear-search").css('display', 'none');
			$('.arrows_search_mobile').fadeOut(0).removeClass("wpr-show");
			$('.wpr-block-title').remove();
			$('.createList_tab').remove();
			$('.createList_mobile').remove();
			$(".search-bar").val("");
		}
	});
	
	//remove non focusing element and activates accessability
	$(document).keydown(function (e) {
		if (e.which == 9) {
			$('.removeFocus').removeClass('removeFocus');
		}
	});
	
	//close menu mobile
	$(".wpr-close-button").click(function () {
		$('body').css({
			"overflow": "auto",
			"position": "initial"
		});
		main_menu.fadeOut(300,"linear").removeClass("wpr-show");
		level_one_menu.fadeOut(300,"linear").removeClass("wpr-show");
		$( ".mobile-submenu-items" ).scrollTop(0);
	});
	
	//close L1 menu with enter key
	$(".wpr-close-button").keydown(function (e) {
		if (e.which == 13) {
			$('body').css({
				"overflow": "auto",
				"position": "initial"
			});
			main_menu.fadeOut(300,"linear").removeClass("wpr-show");
			level_one_menu.fadeOut(300,"linear").removeClass("wpr-show");
			$( ".mobile-submenu-items" ).scrollTop(0);
		}
	});
		
	// for submenu it hides the level one menu and opens the level two menu
	$(".Rectangle-515").click(function () {
		var connected_submenu_mobile = this.id + '_sub';
		connected_submenu_mobile_obj = $('#' + connected_submenu_mobile + '');
		// this hides the level one menu and shows the the level two menu
		connected_submenu_mobile_obj.fadeIn(0).addClass("wpr-show");
		level_one_menu.fadeOut(0).removeClass("wpr-show");
		$( ".mobile-submenu-items" ).scrollTop(0);
	});
	
	//open submenu with enter key
	$(".Rectangle-515").keydown(function (e) {
		if (e.which == 13) {
			var connected_submenu_mobile = this.id + '_sub';
			connected_submenu_mobile_obj = $('#' + connected_submenu_mobile + '');
			// this hides the level one menu and shows the the level two menu
			connected_submenu_mobile_obj.fadeIn(0).addClass("wpr-show");
			level_one_menu.fadeOut(0).removeClass("wpr-show");
				$( ".mobile-submenu-items" ).scrollTop(0);
		}
	});
	
	// go to L1 menu with mouse click
	$(".back_icon").click(function () {
		// this hides the level two menu and shows the level one menu
		level_two_menu.fadeOut(0).removeClass("wpr-show");
		level_one_menu.fadeIn(0).addClass("wpr-show");
		$( ".mobile-submenu-items" ).scrollTop(0);
	});
	
	// go to L1 menu with enter key
	$(".back_icon").keydown(function (e) {
		if (e.which == 13) {
			// this hides the level two menu and shows the level one menu
			$('body').css({
				"overflow": "auto",
				"position": "initial"
			});
			level_two_menu.fadeOut(0).removeClass("wpr-show");
			level_one_menu.fadeIn(0).addClass("wpr-show");
			$( ".mobile-submenu-items" ).scrollTop(0);
		}
	});
	
	$(".wpr-close-button-L2").click(function () {
		// hides all the menu L1 and L2 and also closes the main menu container
		$('body').css({
			"overflow": "auto",
			"position": "initial"
		});
		main_menu.fadeOut(300,"linear").removeClass("wpr-show");
		level_one_menu.fadeOut(300,"linear").removeClass("wpr-show");
		level_two_menu.fadeOut(300,"linear").removeClass("wpr-show");
		$( ".mobile-submenu-items" ).scrollTop(0);
	});
	
	$(".wpr-close-button-L2").keydown(function (e) {
		if (e.which == 13) {
			// hides all the menu L1 and L2 and also closes the main menu container'
			$('body').css({
				"overflow": "auto",
				"position": "initial"
			});
			main_menu.fadeOut(300,"linear").removeClass("wpr-show");
			level_one_menu.fadeOut(300,"linear").removeClass("wpr-show");
			level_two_menu.fadeOut(300,"linear").removeClass("wpr-show");
				$( ".mobile-submenu-items" ).scrollTop(0);
		}
	});

	//End of mobile js
	
	//Desktop and tablet 
    //header links in desktop when ckicked activate the menu which is connecte with them with id
	$(".navbar-header-links").hover(function () {

		if(country_flag){//for RTL Languages
			$('.arrows_search_tab_desk').hide();
			$('.overlay_closing_search').hide();
			$('.wpr-block-title').remove();
			$('.createList_tab').remove();
			$('.createList_mobile').remove();
			$(".search-bar").val("");
			$('#search_focus_desktop').blur();
			$(".clear-search").css('display', 'none');

		all_nav_submenu.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
		var connected_menu = this.id;
		var connected_submenu = this.id + '_drop';
		connected_menu_obj = $('#' + connected_menu + '');
		offset = connected_menu_obj.offset();
		connected_submenu_obj = $('#' + connected_submenu + '');
		connected_menu_obj.addClass("underline");
		connected_menu_obj.addClass("active");
		connected_submenu_obj.addClass("wpr-show");
		tab_drop_container.addClass("wpr-show");
		offset_right = screen_size-(offset.left + connected_menu_obj.width());
		close_menu_position = connected_submenu_obj.height() + 106;
		$('.wpr-dropdown-nav-footer').css({
			"top": close_menu_position
		});
		if (screen_size > offset_right + connected_submenu_obj.width()) {
			if (screen_size >= 1450) {
				connected_submenu_obj.css({
					"right": offset_right - 80,
					"transform": "translateX(0%)"
				});
			} else {

				connected_submenu_obj.css({
					"right": offset_right - 30,
					"transform": "translateX(0%)"
				});
			}
		} else {

			connected_submenu_obj.css({
				"right": "50%",
				"transform": "translateX(50%)"
			});
		}
		
		}else{//for normal Languages
			$('.arrows_search_tab_desk').hide();
			$('.overlay_closing_search').hide();
			$('.wpr-block-title').remove();
			$('.createList_tab').remove();
			$('.createList_mobile').remove();
			$(".search-bar").val("");
			$('#search_focus_desktop').blur();
			$(".clear-search").css('display', 'none');

		all_nav_submenu.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
		var connected_menu = this.id;
		var connected_submenu = this.id + '_drop';
		connected_menu_obj = $('#' + connected_menu + '');
		offset = connected_menu_obj.offset();
		connected_submenu_obj = $('#' + connected_submenu + '');
		connected_menu_obj.addClass("underline");
		connected_menu_obj.addClass("active");
		connected_submenu_obj.addClass("wpr-show");
		tab_drop_container.addClass("wpr-show");

		close_menu_position = connected_submenu_obj.height() + 106;
		$('.wpr-dropdown-nav-footer').css({
			"top": close_menu_position
		});
		
		if (screen_size > offset.left + connected_submenu_obj.width()) {
			if (screen_size >= 1450) {
				connected_submenu_obj.css({
					"left": offset.left - 80,
					"transform": "translateX(0%)"
				});
			} else {

				connected_submenu_obj.css({
					"left": offset.left - 30,
					"transform": "translateX(0%)"
				});
			}
		} else {

			connected_submenu_obj.css({
				"left": "50%",
				"transform": "translateX(-50%)"
			});
		}

		}
	});
	
	//open menu by enter key in desktop
	$(".navbar-header-links").keydown(function (e) {
		if (e.which == 13) {

			if(country_flag){//for RTL Languages

				$('.arrows_search_tab_desk').hide();
				$('.overlay_closing_search').hide();
				$('.wpr-block-title').remove();
				$('.createList_tab').remove();
				$('.createList_mobile').remove();
				$(".search-bar").val("");
				$('#search_focus_desktop').blur();
				$(".clear-search").css('display', 'none');

			all_nav_submenu.removeClass("wpr-show");
			navbar_links_tab_underline.removeClass("underline");
			navbar_links_tab_underline.removeClass("active");
			var connected_menu = this.id;
			var connected_submenu = this.id + '_drop';
			connected_menu_obj = $('#' + connected_menu + '');
			offset = connected_menu_obj.offset();
			connected_submenu_obj = $('#' + connected_submenu + '');
			connected_menu_obj.addClass("underline");
			connected_menu_obj.addClass("active");
			connected_submenu_obj.addClass("wpr-show");
			tab_drop_container.addClass("wpr-show");
			offset_right = screen_size-(offset.left + connected_menu_obj.width());
			close_menu_position = connected_submenu_obj.height() + 106;
			$('.wpr-dropdown-nav-footer').css({
			"top": close_menu_position
			});
			if (screen_size > offset_right + connected_submenu_obj.width()) {
				if (screen_size >= 1450) {
					connected_submenu_obj.css({
						"right": offset_right - 80,
						"transform": "translateX(0%)"
					});
				} else {
	
					connected_submenu_obj.css({
						"right": offset_right - 30,
						"transform": "translateX(0%)"
					});
				}
			} else {
	
				connected_submenu_obj.css({
					"right": "50%",
					"transform": "translateX(50%)"
				});
			}
			
			}else{//for normal Languages
	
				$('.arrows_search_tab_desk').hide();
				$('.overlay_closing_search').hide();
				$('.wpr-block-title').remove();
				$('.createList_tab').remove();
				$('.createList_mobile').remove();
				$(".search-bar").val("");
				$('#search_focus_desktop').blur();
				$(".clear-search").css('display', 'none');

	
			all_nav_submenu.removeClass("wpr-show");
			navbar_links_tab_underline.removeClass("underline");
			navbar_links_tab_underline.removeClass("active");
			var connected_menu = this.id;
			var connected_submenu = this.id + '_drop';
			connected_menu_obj = $('#' + connected_menu + '');
			offset = connected_menu_obj.offset();
			connected_submenu_obj = $('#' + connected_submenu + '');
			connected_menu_obj.addClass("underline");
			connected_menu_obj.addClass("active");
			connected_submenu_obj.addClass("wpr-show");
			tab_drop_container.addClass("wpr-show");
			close_menu_position = connected_submenu_obj.height() + 106;
			$('.wpr-dropdown-nav-footer').css({
			"top": close_menu_position
			});
			if (screen_size > offset.left + connected_submenu_obj.width()) {
				if (screen_size >= 1450) {
					connected_submenu_obj.css({
						"left": offset.left - 80,
						"transform": "translateX(0%)"
					});
				} else {
	
					connected_submenu_obj.css({
						"left": offset.left - 30,
						"transform": "translateX(0%)"
					});
				}
			} else {
	
				connected_submenu_obj.css({
					"left": "50%",
					"transform": "translateX(-50%)"
				});
			}
	
			}
		}
	});
	
	//close button for desktop
	$(".wpr-close-submenu-desk").click(function () {
		tab_drop_container.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
	});
	
	//close menu by enter key in desktop
 	$(".wpr-close-submenu-desk").keydown(function (e) {
		if (e.which == 13) {
			tab_drop_container.removeClass("wpr-show");
			navbar_links_tab_underline.removeClass("underline");
			navbar_links_tab_underline.removeClass("active");
		}
	});
 	
	//close desktop button for tablet
	$(".wpr-drop-close-button-tab").click(function () {
		tab_drop_container.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
	})
	
	//close desktop menu with overlay
	$(".wpr-closing-overlay").click(function () {
		tab_drop_container.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
	});
	
	//close desktop menu by clicking on search
	$(".tab-search").click(function () {
		tab_drop_container.removeClass("wpr-show");
		navbar_links_tab_underline.removeClass("underline");
		navbar_links_tab_underline.removeClass("active");
	});
	
	//close opened modals with escape key
	$(document).keydown(function (e) {
		if (e.which == 27) {
			//closing desktop menu
			tab_drop_container.removeClass("wpr-show");
			navbar_links_tab_underline.removeClass("underline");
			navbar_links_tab_underline.removeClass("active");
			//closing search
			$('.arrows_search_tab_desk').hide();
			$('.overlay_closing_search').hide();
			$('.wpr-block-title').remove();
			$('.createList_tab').remove();
			$('.createList_mobile').remove();
			$(".search-bar").val("");
			$(".clear-search").css('display', 'none');
			//closing mobile menu with esc
			// hides all the menu L1 and L2 and also closes the main menu container
			main_menu.removeClass("wpr-show");
			level_one_menu.removeClass("wpr-show");
			level_two_menu.removeClass("wpr-show");
			//closing country selector with esc
			$('.world_map').css('visibility', 'hidden');
			//closing mobile countryselector with escape
			$('.close_btn_mobile_countries').blur();
			closeMobileCountry();
		}
	});
	
	//resizessss function to check if the opend modal has enough room to fit
	$(window).resize(function () {	
		
		if(country_flag){//for RTL Languages
			if (connected_submenu_obj != '') {
		offset = connected_menu_obj.offset();
		set_screensize();
		offset_right = screen_size-(offset.left + connected_menu_obj.width());
				if (screen_size > offset_right + connected_submenu_obj.width()) {
					if (screen_size >= 1450) {
						connected_submenu_obj.css({
							"right": offset_right - 80,
							"transform": "translateX(0%)"
						});
					} else {
						connected_submenu_obj.css({
							"right": offset_right - 30,
							"transform": "translateX(0%)"
						});
					}
				} else {
		
					connected_submenu_obj.css({
						"right": "50%",
						"transform": "translateX(50%)"
					});
				}
			}
		}else{//for normal Languages
		set_screensize();
			if (connected_submenu_obj != '') {
				offset = connected_menu_obj.offset();
				if (screen_size > offset.left + connected_submenu_obj.width()) {
					if (screen_size >= 1450) {
						connected_submenu_obj.css({
							"left": offset.left - 80,
							"transform": "translateX(0%)"
						});
					} else {
						connected_submenu_obj.css({
							"left": offset.left - 30,
							"transform": "translateX(0%)"
						});
					}
				} else {
					connected_submenu_obj.css({
						"left": "50%",
						"transform": "translateX(-50%)"
					});
				}
		
			}
		}
	});
	//resizessss function ends
	
	// removes outline border from various elements[1.finds if the element is clicked 2. if condition is true adds "removefocus" class]
	$(document).mousedown(function (e) {

		var containerCloseButton = $(".close_icon_desk ");
		if (!containerCloseButton.is(e.target) && containerCloseButton.has(e.target).length === 0) {
			//nothing
		} else {
			containerCloseButton.addClass("removeFocus");
		}
		
		var containerLogo = $(".wpr-main-logo");
		if (!containerLogo.is(e.target) && containerLogo.has(e.target).length === 0) {
			//nothing
		} else {
			containerLogo.addClass("removeFocus");
		}
		
		var containerSearch = $(".wpr-search-icon-logo");
		if (!containerSearch.is(e.target) && containerSearch.has(e.target).length === 0) {
			//nothing
		} else {
			containerSearch.addClass("removeFocus");
		}
		
		var containerMenu = $(".wpr-menu-icon-logo");
		if (!containerMenu.is(e.target) && containerMenu.has(e.target).length === 0) {
			//nothing
		} else {
			containerMenu.addClass("removeFocus");
		}
		
		var containerLinks = $(".navbar-header-links");
		if (!containerLinks.is(e.target) && containerLinks.has(e.target).length === 0) {
			//nothing
		} else {
			containerLinks.addClass("removeFocus");
		}
		
		var containerIconClear = $(".wpr-clear-icon-logo");
		if (!containerIconClear.is(e.target) && containerIconClear.has(e.target).length === 0) {
			//nothing
		} else {
			containerIconClear.addClass("removeFocus");
		}
		
		var containerCart = $(".wpr-hpcart");
		if (!containerCart.is(e.target) && containerCart.has(e.target).length === 0) {
			//nothing
		} else {
			containerCart.addClass("removeFocus");
		}
		
		var containerMenuOption = $(".Rectangle-505");
		if (!containerMenuOption.is(e.target) && containerMenuOption.has(e.target).length === 0) {
			//nothing
		} else {
			containerMenuOption.addClass("removeFocus");
		}
		
		var containerCountry = $(".country_selector");
		if (!containerCountry.is(e.target) && containerCountry.has(e.target).length === 0) {
			//nothing
		} else {
			containerCountry.addClass("removeFocus");
		}
		
		var containerFooterLinks = $(".link_metrics");
		if (!containerFooterLinks.is(e.target) && containerFooterLinks.has(e.target).length === 0) {
			//nothing
		} else {
			containerFooterLinks.addClass("removeFocus");
		}
		
		var containerCSClose= $(".cselectorbtn");
		if (!containerCSClose.is(e.target) && containerCSClose.has(e.target).length === 0) {
			//nothing
		} else {
			containerCSClose.addClass("removeFocus");
		}	
		var containerCountrySelec= $(".country_sel_cont_header");
		if (!containerCountrySelec.is(e.target) && containerCountrySelec.has(e.target).length === 0) {
			//nothing
		} else {
			containerCountrySelec.addClass("removeFocus");
		}	

		var close_btn_mobile_countries= $(".close_btn_mobile_countries");
		if (!close_btn_mobile_countries.is(e.target) && close_btn_mobile_countries.has(e.target).length === 0) {
			//nothing
		} else {
			close_btn_mobile_countries.addClass("removeFocus");
		}	
		
		var ul_site_link_header= $(".ul_site_link_header");
		if (!ul_site_link_header.is(e.target) && ul_site_link_header.has(e.target).length === 0) {
			//nothing
		} else {
			ul_site_link_header.addClass("removeFocus");
		}	
		
		var ul_site_link_header= $(".ul_site_link_header");
		if (!ul_site_link_header.is(e.target) && ul_site_link_header.has(e.target).length === 0) {
			//nothing
		} else {
			ul_site_link_header.addClass("removeFocus");
		}	


		var FooterLinks= $('.tab_list>li>a');
		if (!FooterLinks.is(e.target) && FooterLinks.has(e.target).length === 0) {
			//nothing
		} else {
			FooterLinks.addClass("removeFocus");
		}	

		
		
	});
	//NAVIGATION JS ENDS
	
	//language specific js
	if (country_flag) {
		$("html[lang=ar]").attr("dir", "rtl").find("body").addClass("right-to-left");
		if (checkResolution() != 'mobile') {
			$('.footer_links_list_container').css('float', 'right');
			// $('.link_metrics').css('margin-right', '13px');
			// $('.tab_list').css('float','right');
		} else {
			$('.accordian_arrow_icon').css('right', 'unset');
			$('.accordian_arrow_icon').css('left', '35px');
		}
		$('.country_selector').css("float", "right");
		$(".footer_links_container ul li").css("text-align", "right");
		$(".popup_b_corner").css("left", "unset");
		$(".popup_b_corner").css("right", "7px");
		$("a.cselectorbtn").css("right", 'unset');
		$("a.cselectorbtn").css("left", "10px");
		$('.countries_div ul li').css('text-align', 'right');
	} else {
		$("html[lang]").attr("dir", "ltr").find("body").addClass("left-to-right");
		if (checkResolution() != 'mobile') {
			$('.footer_links_list_container').css('float', 'left');
			//$('.link_metrics').css('margin-right', '');
			//$('.tab_list').css('float','left');
		} else {
			$('.accordian_arrow_icon').css('left', 'unset');
			$('.accordian_arrow_icon').css('right', '35px !important');
		}
		$('.country_selector').css("float", "left");
		$(".footer_links_container ul li").css("text-align", "left");
		$(".popup_b_corner").css("right", "unset");
		$(".popup_b_corner").css("left", "7px");
		$("a.cselectorbtn").css("left", "unset");
		$("a.cselectorbtn").css("right", "10px");
		$('.countries_div ul li').css('text-align', 'left');
	}
	if (checkResolution() == 'mobile') {
		$("#id_6").hide();
	}

	/*Function for country selector*/


	$( ".close_btn_mobile_countries" ).focus(function() {
		$('.close_btn_mobile_countries').attr('tabindex', '802');
	  });

	  $( ".close_btn_mobile_countries" ).blur(function() {
		$('.close_btn_mobile_countries').attr('tabindex', '805');
	  });

	  $('.wpr-side-nav-footer>.wpr-close-button>.close_icon').focus(function (){
		$('.wpr-side-nav-footer>.wpr-close-button>.close_icon').attr('tabindex', '2');
	  });

	  $( '.wpr-side-nav-footer>.wpr-close-button>.close_icon').blur(function() {
		$('.wpr-side-nav-footer>.wpr-close-button>.close_icon').attr('tabindex', '6');
	  });
	 
	  var latest_tabindex = 0;
	 
	  $('.wpr-side-nav-footer>.wpr-close-button-L2>.close_icon').focus(function (){
		latest_tabindex = $(this).attr("tabindex");
		latest_tabindex = latest_tabindex - 1; 
		$('.wpr-side-nav-footer>.wpr-close-button-L2>.close_icon').attr('tabindex', latest_tabindex);
	  });

	  
	  $('.wpr-side-nav-footer>.wpr-close-button-L2>.close_icon').blur(function (){ 
		latest_tabindex = $(this).attr("tabindex");
		latest_tabindex = parseFloat(latest_tabindex) + 1; 
		$('.wpr-side-nav-footer>.wpr-close-button-L2>.close_icon').attr('tabindex', latest_tabindex);
	  });

	$('.country_sel_cont').click(function () {
		idname = this.id;
		if (checkResolution() == 'mobile') {
			hide_except_all_country_mobile(idname);
			if (this.lastElementChild.style.display === "none") {
				//this.lastElementChild.style.display = "block";
				$(this).children(".tab_list_country_selec").slideDown(300, "linear");
				$(this).children('.country_sel_cont_header').css("background-color", "#007DBA");
				$(this).children('.country_sel_cont_header').attr('aria-expanded', 'true');
				$(this).children('.country_sel_cont_header').children().css("color", "#ffffff");
				$(this).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').css("transform", "rotate(180deg)");
				$(this).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').children().children('.clss-1').css("fill", "#ffffff");
			} else {
				$(this).children(".tab_list_country_selec").slideUp(300, "linear");
				$(this).children('.country_sel_cont_header').css("background-color", "#ffffff");
				$(this).children('.country_sel_cont_header').attr('aria-expanded', 'false');
				$(this).children('.country_sel_cont_header').children().css("color", "#8e8e8e");
				$(this).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').css("transform", "rotate(0deg)");
				$(this).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').children().children('.clss-1').css("fill", "#e0e0e0");
			}
		}
	});
	hide_all_country_mobile();
	
	// function to hide all links
	function hide_all_country_mobile() {
		var x = document.getElementsByClassName('country_sel_cont');
		for (let index = 0; index < x.length; index++) {
			if (x[index].lastElementChild) x[index].lastElementChild.style.display = "none";
		}
	}
	
	// function to hide all except the clicked one;
	function hide_except_all_country_mobile(idname) {
		var x = document.getElementsByClassName('country_sel_cont');
		for (let index = 0; index < x.length; index++) {
			if (idname === x[index].id) {} else {
				//x[index].lastElementChild.style.display = "none";
				$(x[index]).children(".tab_list_country_selec").slideUp(300, "linear");
				$(x[index]).children('.country_sel_cont_header').css("background-color", "#ffffff");
				$(x[index]).children('.country_sel_cont_header').attr('aria-expanded', 'false');
				$(x[index]).children('.country_sel_cont_header').children().css("color", "#8e8e8e");
				$(x[index]).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').css("transform", "rotate(0deg)");
				$(x[index]).children('.country_sel_cont_header').children('.accordian_arrow_icon_country').children().children('.clss-1').css("fill", "#e0e0e0");
			}
		}
	}
	
	/*Function for country selector------End*/

	/*Function for footer*/
	$('.ul_site_link_header').click(function () {

		idname = $(this).parent().attr("id");
        id = '#'+idname+'';
		id_inner = ''+idname+'';

		if (checkResolution() == 'mobile') {
			hide_except(idname);
			if(document.getElementById(id_inner).lastElementChild.style.display == "none") {
				//this.lastElementChild.style.display = "block";
				$(id).children(".tab_list").slideDown(500, "linear");
				$(id).children('.ul_site_link_header').css("background-color", "#e8e8e8");
				$(id).children('.ul_site_link_header').attr('aria-expanded', 'true');
				$(id).children('.ul_site_link_header').children('.accordion-header').css("color", "#5a5a5a");
				$(id).children('.ul_site_link_header').children('.accordion-header').css("text-decoration", "underline");
				$(id).children('.ul_site_link_header').children('.accordian_arrow_icon').css("color", "#5a5a5a");
				$(id).children('.ul_site_link_header').children('.accordian_arrow_icon').css("transform", "rotate(180deg)");
			} else {
				$(id).children(".tab_list").slideUp(500, "linear");
				$(id).children('.ul_site_link_header').css("background-color", "#5a5a5a");
				$(id).children('.ul_site_link_header').attr('aria-expanded', 'false');
				$(id).children('.ul_site_link_header').children('.accordion-header').css("color", "#ffffff");
				$(id).children('.ul_site_link_header').children('.accordion-header').css("text-decoration", "unset");
				$(id).children('.ul_site_link_header').children('.accordian_arrow_icon').css("color", "#ffffff");
				$(id).children('.ul_site_link_header').children('.accordian_arrow_icon').css("transform", "rotate(0deg)");
			}
		}
	});
	
	hide_all();
	// function to hide all ul links
	function hide_all() {
		var x = document.getElementsByClassName('footer_links_list_container');
		for (let index = 0; index < x.length; index++) {
			x[index].lastElementChild.style.display = "none";
			$(x[index]).children('.ul_site_link_header').css("background-color", "#5a5a5a");
			$(x[index]).children('.ul_site_link_header').attr('aria-expanded', 'false');
			$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("color", "#ffffff");
			$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("text-decoration", "unset");
			$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("color", "#ffffff");
			$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("transform", "rotate(0deg)");
		}
	}
	
	// function to hide all except the clicked one;
	function hide_except(idname) {
		var x = document.getElementsByClassName('footer_links_list_container');
		for (let index = 0; index < x.length; index++) {
			if (idname === x[index].id) {} else {
				//x[index].lastElementChild.style.display = "none";
				$(x[index]).children(".tab_list").slideUp(500, "linear");
				$(x[index]).children('.ul_site_link_header').css("background-color", "#5a5a5a");
				$(x[index]).children('.ul_site_link_header').attr('aria-expanded', 'false');
				$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("color", "#ffffff");
				$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("text-decoration", "unset");
				$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("color", "#ffffff");
				$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("transform", "rotate(0deg)");
			}
		}
	}
	$('ul.footer_privacy_links li:last-child span').css('display', 'none');

	$('.country_selector').on('click', function (e) {
		
		$(".country_sel_cont_header").attr('tabindex', '802');
		$(".close_btn_mobile_countries").attr('tabindex', '804');

		if (checkResolution() == 'mobile') {
			$('body').css({
				"overflow": "hidden",
				"position": "relative"
			});
		}
		e.preventDefault();
		if (country_flag) {
			if (checkResolution() == 'mobile') {
				$('.closing_overlay_mobile').css('display', 'block');
				hide_all();
				$('.right_corner').show();
				$('.test_sidebar').css({
					"right": "0%",
					"transition-duration": "300ms"
				});
				$('body').css({
					"right": "85%",
					"transition-duration": "300ms"
				});
			} else {
				$('.world_map').css('visibility', 'visible');
				$('.world_map').css('right', '-1%');
				$('.div_worldmap h2').css('margin', '20px 20px 0 0');
				$('.countries_div').css('padding', '20px 20px 0 0');
			}
		} else if (checkResolution() == 'mobile') {
			$('.closing_overlay_mobile').css('display', 'block');
			hide_all();
			$('.right_corner').show();
			$('.test_sidebar').css({
				"left": "0%",
				"transition-duration": "300ms"
			});
			$('body').css({
				"left": "85%",
				"transition-duration": "300ms"
			});
		} else {
			$('.world_map').css('visibility', 'visible');
			$('.world_map').css('left', '-1%');
			$('.closing_overlay').css('display', 'block');
		}
	});


	$('.country_selector').keydown(function (e) {
		
		if (e.which == 13) {
		$(".country_sel_cont_header").attr('tabindex', '802');
		$(".close_btn_mobile_countries").attr('tabindex', '804');

		if (checkResolution() == 'mobile') {
			$('body').css({
				"overflow": "hidden",
				"position": "relative"
			});
		}
		e.preventDefault();
		if (country_flag) {
			if (checkResolution() == 'mobile') {
				$('.closing_overlay_mobile').css('display', 'block');
				hide_all();
				$('.right_corner').show();
				$('.test_sidebar').css({
					"right": "0%",
					"transition-duration": "300ms"
				});
				$('body').css({
					"right": "85%",
					"transition-duration": "300ms"
				});
			} else {
				$('.world_map').css('visibility', 'visible');
				$('.world_map').css('right', '-1%');
				$('.div_worldmap h2').css('margin', '20px 20px 0 0');
				$('.countries_div').css('padding', '20px 20px 0 0');
			}
		} else if (checkResolution() == 'mobile') {
			$('.closing_overlay_mobile').css('display', 'block');
			hide_all();
			$('.right_corner').show();
			$('.test_sidebar').css({
				"left": "0%",
				"transition-duration": "300ms"
			});
			$('body').css({
				"left": "85%",
				"transition-duration": "300ms"
			});
		} else {
			$('.world_map').css('visibility', 'visible');
			$('.world_map').css('left', '-1%');
			$('.closing_overlay').css('display', 'block');
		}

	}
	});

	
	function closeMobileCountry() {
		$(".country_sel_cont_header").attr('tabindex', '-1');
		$(".close_btn_mobile_countries").attr('tabindex', '-1');
		$('.closing_overlay_mobile').css('display', 'none');
		$('body').css('overflow', 'auto');
		if (country_flag) {
			$('.right_corner').hide();
			$('.test_sidebar').css({
				"right": "-100%",
				"transition-duration": "300ms"
			});
			$('body').css({
				"right": "0%",
				"transition-duration": "300ms"
			});
		} else {
			$('.right_corner').hide();
			$('.test_sidebar').css({
				"left": "-100%",
				"transition-duration": "300ms"
			});
			$('body').css({
				"left": "0%",
				"transition-duration": "300ms"
			});
		}
	}
	
	$('.close_btn_mobile_countries').click(function () {
		$('.close_btn_mobile_countries').blur();
		closeMobileCountry();
	});
	$('.cselectorbtn').click(function () {
		$('.world_map').css('visibility', 'hidden');
		$('.closing_overlay').css('display', 'none');
	});
	setPath();
	
	if (checkResolution() == 'mobile') {
		$('ul.tab_list').hide();
		$('.ul_site_link_header').css('display', 'flex');
	} else {
		$('ul.tab_list').show();
		$('.ul_site_link_header').css('display', 'none');
	}
	
	signUpEmail();
	/* Code for Shopping Cart starts here */
	$.ajax({
		type: "GET",
		dataType: 'jsonp',
		jsonpCallback: 'cartStatus',
		async: true,
		url: $("#serviceUrl").text(),
		data: {
			/*pass your request parameter here*/
		},
		success: function (data, textStatus, jqXHR) {
			var json = JSON.stringify(data);
			json = JSON.parse(json);
			if (json.noOfItems != '0') {
				
					$("#counterMobile").show();
					$("#counterMobile").append(json.noOfItems);
			
					$("#counterDesktop").show();
					$("#counterDesktop").append(json.noOfItems);
				
			} else {
				$("#counterMobile").hide();
				$("#counterDesktop").hide();
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {}
	});
	/* Code for Shopping Cart ends here */
	//Code for lady bug starts here
	/*
	$.ajax({
		type: "GET",
		url: '/bin/custom/ladyBug',
		data : {
		    pass your request parameter here, currently we are not passing any data
		},
		success: function (data, textStatus, jqXHR) {
			var json = JSON.parse(data);
			//var msgId=   json.ipExist;
			setCookies(json);
			showLadyBug();
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {

		}
	});

	function setCookies(cookieVal) {
		//Cookies.set("HP_LB_5", cookieVal); 
		document.cookie = "HP_LB_5=" + cookieVal;
	}

	return null;

	function showLadyBug() {
		var myCookie = getCookie('HP_LB_5');

		if (myCookie == "0") {
			$("#ladybug_container").hide();
		} else {
			$("#ladybug_container").show();
		}
		return null;
	}

	function getCookie(name) {
		var re = new RegExp(name + "=([^;]+)");
		var value = re.exec(document.cookie);
		return (value != null) ? unescape(value[1]) : null;
	}*/
	//Code for lady bug ends here
});

var country_flag = $('html').is(':lang(ar)');
function setPath() {
	var path = window.location.pathname + "";
	var part1 = path.indexOf('/');
	var part2 = path.indexOf('/', part1 + 1);
	var part3 = path.indexOf('/', part2 + 1);
	var part4 = path.indexOf('/', part3 + 1);
	var part5 = path.indexOf('/', part4 + 1);
	var page_name = path.slice(part3);
	var page_name_aem = path.slice(part5);
	for (var i = 0; i < $('#countrylist li').length; i++) {
		if ($('a#countryId').eq(i)[0]) {
			$('a#countryId').eq(i)[0].href = $('a#countryId').eq(i)[0].href + page_name;
		}
		if ($('a#countryIdAem').eq(i)[0]) {
			$('a#countryIdAem').eq(i)[0].href = $('a#countryIdAem').eq(i)[0].href + page_name_aem;
		}
		if ($('a#countryIdM').eq(i)[0]) {
			$('a#countryIdM').eq(i)[0].href = $('a#countryIdM').eq(i)[0].href + page_name;
		}
		if ($('a#countryIdAemM').eq(i)[0]) {
			$('a#countryIdAemM').eq(i)[0].href = $('a#countryIdAemM').eq(i)[0].href + page_name_aem;
		}
	}
}

function checkResolution() {
	var resolution = $(window).outerWidth();
	var screen;
	if (resolution <= 767) {
		screen = "mobile";
	} else if (resolution >= 768 && resolution <= 1080) {
		screen = "tab";
		$(".footer_links div.footer_links_list_container:last-child").css('margin-right', '0px');
	} else if (resolution > 1080) {
		screen = "desktop";
		$(".footer_links div.footer_links_list_container:last-child").css('margin-right', '0px');
	}
	initcountries(screen);
	return screen;
}

function closeMobileCountry() {
	$('body').css('overflow', 'auto');
	if (country_flag) {
		$('.right_corner').hide();
		$('.test_sidebar').css({
			"right": "-100%",
			"transition-duration": "300ms"
		});
		$('body').css({
			"right": "0%",
			"transition-duration": "300ms"
		});
	} else {
		$('.right_corner').hide();
		$('.test_sidebar').css({
			"left": "-100%",
			"transition-duration": "300ms"
		});
		$('body').css({
			"left": "0%",
			"transition-duration": "300ms"
		});
	}
}

var screen_size = $(window).width();

$(window).resize(function () {
	if($(window).width()!=screen_size){
	$('.closing_overlay_mobile').css('display', 'none');
	checkResolution();
	closeMobileCountry();
	if (checkResolution() != 'mobile') {
		if (country_flag) {
			$('.footer_links_list_container').css('float', 'right');
			//$('.link_metrics').css('margin-right', '13px');
		} else {
			$('.footer_links_list_container').css('float', 'left');
			// $('.link_metrics').css('margin-right', '');
		}
	} else if ((country_flag) && (checkResolution() == 'mobile')) {
		$('.closing_overlay_mobile').css('display', 'none');
		$('.accordian_arrow_icon').css('right', 'unset');
		$('.accordian_arrow_icon').css('left', '35px !important');
		$('.footer_links_list_container').css('float', 'none');
		$('.link_metrics').css('margin-right', '');
	} else {
		$('.closing_overlay_mobile').css('display', 'none');
		$('.footer_links_list_container').css('float', 'none');
		$('.link_metrics').css('margin-right', '');
		$('.accordian_arrow_icon').css('left', 'unset');
		$('.accordian_arrow_icon').css('right', '35px !important');
	}
	if (checkResolution() == 'mobile') {
		$("#id_6").hide();
	} else {
		$("#id_6").show();
	}
	var responsive_scr = checkResolution();
	if (responsive_scr == 'mobile') {
		$('ul.tab_list').hide();

		var x = document.getElementsByClassName('footer_links_list_container');
		for (let index = 0; index < x.length; index++) {
			$(x[index]).children('.ul_site_link_header').css("background-color", "#5a5a5a");
			$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("color", "#ffffff");
			$(x[index]).children('.ul_site_link_header').children('.accordion-header').css("text-decoration", "unset");
			$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("color", "#ffffff");
			$(x[index]).children('.ul_site_link_header').children('.accordian_arrow_icon').css("transform", "rotate(0deg)");
		}

		$('.ul_site_link_header').css('display', 'flex');
	} else {
		$('ul.tab_list').show();
		$('.ul_site_link_header').css('display', 'none');
	}
}
screen_size = $(window).width();
});

function initcountries(screen) {
	if (screen == "desktop") {
		var colnumber = 7;
	} else if (screen == "tab") {
		var colnumber = 5;
	} else if (screen == "mobile") {
		return;
	}
	var els = $('#countrylist').find("li");
	var elswidth = els.outerWidth();
	var line = Math.ceil(els.length / colnumber);
	var col = 1;
	var prevColHeight = 0;
	els.each(function (index, el) {
		el = $(el);
		marginTop = "";
		if (index == line * col) {
			col++;
			marginTop = -prevColHeight + "px";
			prevColHeight = 0;
		}
		prevColHeight += els.outerHeight();
		if (country_flag) {
			el.css("margin-right", elswidth * (col - 1) + "px");
		} else {
			el.css("margin-left", elswidth * (col - 1) + "px");
		}
		el.css("margin-top", marginTop);
	})
}

/* Code for email signup starts here */
function signUpEmail() {
	var element = $("#footer_email_input");
	element.on("keyup", function (event) {
		if (event.keyCode == 13) {
			document.getElementById("footer_email_submit").click();
		}
	});
	$("#footer_email_submit").click(function (e) {
		e.preventDefault();
		var emailId = $("#footer_email_input").val();
		var cookieName = "SIGNUPEMAIL";
		var newLocation = $("#footer_email_submit").attr("href");
		if (emailId == "") return;

		function setCookie(cookieName, email) {
			document.cookie = cookieName + "=" + email;
			return document.cookie;
		}
		setCookie(cookieName, emailId);
		window.location.href = newLocation;
	});
}
/* Code for email signup ends here */

$('.closing_overlay').click(function (){
	$('.world_map').css('visibility', 'hidden');
	$('.closing_overlay').css('display', 'none');
});

$('.closing_overlay_mobile').click(function (e) {

	$(".country_sel_cont_header").attr('tabindex', '-1');
	$(".close_btn_mobile_countries").attr('tabindex', '-1');

	var mob_container = $('.test_sidebar');
	if (checkResolution() == 'mobile') {
		$('.closing_overlay_mobile').css('display', 'none');
			if (country_flag) {
				$('body').css('overflow', 'auto');
				$('.right_corner').hide();
				mob_container.css({
					'right': '-100%',
					'transition-duration': '300ms'
				});
				$('body').css({
					'right': '0%',
					'transition-duration': '300ms'
				});
			} else {
				$('body').css('overflow', 'auto');
				$('.right_corner').hide();
				mob_container.css({
					'left': '-100%',
					'transition-duration': '300ms'
				});
				$('body').css({
					'left': '0%',
					'transition-duration': '300ms'
				});
			}
		
	} else {
		// do nothing
	}
});

$(document).keyup(function (e) {
	var container = $(".country_selector");
	if (container.is(':focus')) {
		container.css('outline', '1px dotted black');
	} else {
		container.css('outline', 'none');
	}
});