// clear search when page loades fix for bug raised 120878
$(".search-bar").val("");

function insertToSearch(e){
	var value = e.innerHTML;

	common = '<span>'
	function replace_span(match) {;
	return '';
	}
	var value = value.replace(RegExp(common, "gi"), replace_span);

    common = '</span>'
	function replace_nextspan(match) {
	return '';
	}
	var value = value.replace(RegExp(common, "gi"), replace_nextspan);

    common = '&amp;'
	function replace_amp(match) {
	return '&';
	}
	var value = value.replace(RegExp(common, "gi"), replace_amp);

    $('.tab-search').val(value);
}

function insertToSearchMobile(e){
	var value = e.innerHTML;

	common = '<span>'
	function replace_span(match) {
	return '';
	}
	var value = value.replace(RegExp(common, "gi"), replace_span);

	common = '</span>'
	function replace_nextspan(match) {
	return '';
	}
	var value = value.replace(RegExp(common, "gi"), replace_nextspan);

    common = '&amp;'
	function replace_amp(match) {
	return '&';
	}
	var value = value.replace(RegExp(common, "gi"), replace_amp);

	$('#search_focus_mobile').val(value);
}

var title1temp=$("#title1").text().replace(/ /g, "_");
var title1=title1temp.replace('.', '-');
var title2=$("#title2").text().replace(/ /g, "_");
var title3=$("#title3").text().replace(/ /g, "_");
var allHpSearching=$("#allHPSearchText").text();
var storeHpSearching=$("#storeHPSearchText").text();
var searchTooltip1=$("#toolTip1").text();
var searchTooltip2=$("#toolTip2").text();

var d1 ;
var d2 ;

$(document).ready(function () {
	const search_container = $(".wpr-search-container");
	sessionStorage.removeItem("key");
	sessionStorage.removeItem(title1.toLowerCase());
	sessionStorage.removeItem(title2.toLowerCase());
	sessionStorage.removeItem(title3.toLowerCase());

});
//clear Search
$('.overlay_closing_search').click(function (){
	$('.arrows_search_tab_desk').hide();
	$('.overlay_closing_search').hide();
	$('.wpr-block-title').remove();
	$('.createList_tab').remove();
	$('.createList_mobile').remove();
    $(".search-bar").val("");
	$(".clear-search").css('display', 'none');

});

$(".clear-search").click(function () {
	$('.arrows_search_tab_desk').hide();
	$('.overlay_closing_search').hide();
	$('.wpr-block-title').remove();
	$('.createList_tab').remove();
	$('.createList_mobile').remove();
    $(".search-bar").val("");
	$(".clear-search").css('display', 'none');
	$('#search_focus_desktop').focus();
	$('#search_focus_mobile').focus();
	$('#search_focus_desktop').attr('title',searchTooltip1);
});

//clear search with enter key
$(".clear-search").keydown(function (e) {
	if (e.which == 13) {
		$('.arrows_search_tab_desk').hide();
		$('.overlay_closing_search').hide();
		$('.wpr-block-title').remove();
		$('.createList_tab').remove();
		$('.createList_mobile').remove();
    	$(".search-bar").val("");
		$(".clear-search").css('display', 'none');
		$('#search_focus_desktop').focus();
		$('#search_focus_mobile').focus();
		$('#search_focus_desktop').attr('title',searchTooltip1);
	}
});

$('.tab-search').keyup(function (event) {
	getListItems(event, 'tab-search');
});

$('.search-bar').keyup(function (event) {
	getListItems(event, 'search-bar');
});
$(".search_trigger").click(function () {

    var searchTextClass;
    if($(window).width()<768)
        searchTextClass='.search-bar';
        else
        searchTextClass='.tab-search'
    var text = $(searchTextClass).val();
    var sText = $(searchTextClass).val().length;
    var url=getSearchResultsURL()+text;
    if(sText>0)
        {
            window.location.href = url;
        }
    
});

$(".search_trigger").on('keydown', function(event) {
	if (event.which == 13) {
		var searchTextClass;
		if($(window).width()<768)
			searchTextClass='.search-bar';
			else
			searchTextClass='.tab-search'
		var text = $(searchTextClass).val();
		var sText = $(searchTextClass).val().length;
		var url=getSearchResultsURL()+text;
		if(sText>0)
			{
				window.location.href = url;
			}
	}
 });

var getListItems = function (event, cName) {

	event.stopImmediatePropagation();
	$('.arrows_search_tab_desk').remove();
	$('.wpr-block-title').remove();
	$('.createList_tab').remove();
	$('.createList_mobile').remove();
	// $('.wpr-tab-search-result').append('<ul class="createList_tab"></ul>');
	var sText = $("." + cName).val().length;
	var text = $("." + cName).val().toLowerCase();
	$(".clear-search").css('display', 'block');

	if (sText >= 2) {

		//$('#search_focus_desktop').attr('title',searchTooltip2);
		if (sessionStorage.getItem("key") != null) {
			var key = sessionStorage.getItem("key");
			if (text.indexOf(key) >= 0) {
				updateAutoSuggestions(text);
			} else {
				getAutoSuggestion(text);
			}
		} else {
			getAutoSuggestion(text);
		}
    }
    else
    {
		if(sText==0)
			{
			  $('.overlay_closing_search').hide();
			  $('.arrows_search_tab_desk').hide();
			  $(".clear-search").css('display','none');
			}
		if(sText<=1)
            $('#search_focus_desktop').attr('title',searchTooltip1);

    	//commenting it for defect #28
    	//$(".clear-search").css('display','none');
    }
}

//open search in mobile
	$(".wpr-search-icon").click(function (event) {
	event.stopImmediatePropagation();
	$('.arrows_search_mobile').fadeToggle(0).toggleClass("wpr-show");
	$(".wpr-search-container").fadeToggle(0).toggleClass("wpr-show");
	$('.createList').remove();
	$(".clear-search").css('display', 'none');
	$('#search_focus_mobile').focus();	 
		return false;
});
	
//open search with enter key
$(".wpr-search-icon").keydown(function (e) {
	if (e.which == 13) {
		event.stopImmediatePropagation();
		$('.arrows_search_mobile').fadeToggle(0).toggleClass("wpr-show");
		$(".wpr-search-container").fadeToggle(0).toggleClass("wpr-show");
		$('.createList').remove();
		$(".clear-search").css('display', 'none');
			$('#search_focus_mobile').focus();	 
			return false;
	}
});

var getAutoSuggestion = function (text) {
	var map = new Map();
	var allStoreHPArray = [];
	var hpStoreArray = [];
	var hpStoreArray2 = [];
	//d1=$.Deferred();
	//d2=$.Deferred();
	
	var paramsOne = {
		q: text,
		lang: $("#languageCode").text().toString(),
		category: 'SS',
		country: $("#countryCode").text().toString()
	};

	var paramsTwo = {
		q: text.toString(),
		lang: $("#languageCode").text().toString()
	};
	sessionStorage.setItem("key", text);
	$("#searchValues li").each(function (index) {
		
		if (index == 0) {
			var url = $(this).text().toString();
			allStoreHPArray = autoSuggestcall1(paramsOne, url, "cb", index, map);

		} else if (index == 1) {
			var url = $(this).text().toString();
			hpStoreArray = addUpdateCache1(url, text, index);

		} else if (index == 2) {
			var url = $(this).text().toString();
			hpStoreArray2 = addUpdateCache2(url, text, index);

		}
	});

	if ($("#searchValues li").length == 1)
{
    d1=$.Deferred();
    title1="AllofHP"
	$.when( d1 ).done(function ( v1 ) {
		map.set(title1, v1);
		
		map.forEach(function (value,key) {
		if(value.length>0)
		addSessionCache(key, value);
	});
	displayMap(map, text);
	
	});
}

if ($("#searchValues li").length == 2)
{
	d1=$.Deferred();
	d2=$.Deferred();
	var screenSize = $(window).width();
	if (screenSize <= 768){
		var searching = '<div class="wpr-block-title">'+title1+'</div><ul class="createList_mobile '+title1+'" id="'+title1+'"> <li class="listCreated_mobile" > <a style="color: #aaaaaa;">'+allHpSearching+'</a></li></ul><div class="wpr-block-title">'+title2+'</div><ul class="createList_mobile '+title2+'" id="'+title2+'"> <li class="listCreated_mobile" > <a style="color: #aaaaaa;" >'+storeHpSearching+'</a></li></ul>';
		$('.wpr-search-result').append(searching);
	}else{
		var searching = '<div class="wpr-block-title">'+title1+'</div><ul class="createList_tab '+title1+'" id="'+title1+'"> <li class="listCreated_tab" > <a style="color: #aaaaaa;">'+allHpSearching+'</a></li></ul><div class="wpr-block-title">'+title2+'</div><ul class="createList_tab '+title2+'" id="'+title2+'"> <li class="listCreated_tab" > <a style="color: #aaaaaa;" >'+storeHpSearching+'</a></li></ul>';
		$('.wpr-tab-search-result').append(searching);
	}
	//var searching ='<div class="wpr-block-title">'+title1+'</div><p>'+allHpSearching+'</p><div class="wpr-block-title">'+title2+'</div><p>'+storeHpSearching+'</p>';
	
	$.when( d1,d2 ).done(function ( v1,v2 ) {
		$('.wpr-tab-search-result').empty();
		$('.wpr-search-result').empty();

		map.set(title1, v1);
		map.set(title2, v2);
		
		map.forEach(function (value,key){
		if(value.length>0)
		addSessionCache(key, value);
    });
	displayMap(map, text);
	
	});
}

if ($("#searchValues li").length == 3)
{
	
	$.when( d1,d2,d3 ).done(function ( v1,v2,v3 ) {
		map.set(title1, v1);
		map.set(title2, v2);
		map.set(title3, v3);
		
		map.forEach(function (value,key){
		if(value.length>0)
		addSessionCache(key, value);
	});
	displayMap(map, text);
	
	});
}
	$('.wpr-tab-search-result').css({
		'opacity': "1",
		"pointer-events": "all",
		"display": "block"
	});

	$('.wpr-search-result').css({
		'opacity': "1",
		"pointer-events": "all",
		"display": "block"
	});

}

function autoSuggestcall1(params, url, callback, index) {
	var allStoreHPArray = [];
	var allStoreHPArray2 = [];
	
	$.ajax({
		url: url,
		data: params,
		success: function (data) {
			var items = data.data.SuggestionItems[0] ? data.data.SuggestionItems[0].list : [];

			for (i = 0; i < items.length; i++) {
				allStoreHPArray.push(items[i].term0);			
			}
			allStoreHPArray2 = allStoreHPArray;
			d1.resolve(allStoreHPArray);			
		},
		error: function () {
		},
		dataType: 'jsonp',
		jsonp: callback
	});

	return allStoreHPArray;
}

function addUpdateCache1(url, text, index) {
	
	var hpStoreArray = [];
	var params = {
		lang: $("#languageCode").text().toString(),
	};
	params.term = text;
	var self = this;
	$.ajax({
		url: url,
		data: params,
		success: function (data) {

			var items = data.terms;
			$.each(items, function () {
				$.each(this, function (key, val) {

					hpStoreArray.push(key);
					// $(".createList_tab").append("<li class='listCreated_tab'>
					// <a href='" + sResultURL2 + "'> " + key + "</a> </li>");

				});
			});
			d2.resolve(hpStoreArray);
		},
		error: function () {
		},
		dataType: 'jsonp',
		jsonp: 'cbf'
	});
	return hpStoreArray;
}

function addUpdateCache2(url, text, index) {

	var hpStoreArray2 = [];

	var params = {
		lang: $("#languageCode").text().toString(),
	};
	params.term = text;
	var self = this;
	$.ajax({
		url: url,
		data: params,
		success: function (data) {

			var items = data.terms;
			$.each(items, function () {
				$.each(this, function (key, val) {

					hpStoreArray2.push(key);
					// $(".createList_tab").append("<li class='listCreated_tab'>
					// <a href='" + sResultURL2 + "'> " + key + "</a> </li>");

				});
			});

		},
		error: function () {
		},
		dataType: 'jsonp',
		jsonp: 'cbf'
	});
	return hpStoreArray2;
}

var displayMap = function (map, text) {
	var numberOfKeys = 0;
	map.forEach(function (value,key){
		numberOfKeys++;
		
	});
	showSuggestion(map, numberOfKeys, text);
}

var showSuggestion = function (map, numberOfKeys, text) {

	var keyNumber = 0;
	if (numberOfKeys == 1)
		keyNumber = 10;
	else if (numberOfKeys == 2)
		keyNumber = 5;
	else if (numberOfKeys == 3)
		keyNumber = 3;
	var screenSize = $(window).width();
    var sResultURL = getSearchResultsURL(text);
    
    String.prototype.insert = function(index, string) {
        if (index > 0)
        {
          return this.substring(0, index) + string + this.substring(index, this.length);
        }
      
        return string + this;
      };
	map.forEach(function (value,key){
		
		if(value.length>0)
		{

        var keyTextTemp=key.replace(/_/g, ' ');
        var keyText=keyTextTemp.replace(/-/g,'.');
		key=key.trim();

		$('#search_focus_desktop').attr('title',searchTooltip2);
            if(numberOfKeys==2)
            {
                if (screenSize < 768)
                $('.wpr-search-result').append('<div class="wpr-block-title">' + keyText + '</div><ul class="createList_mobile ' + key + '" id="'+ key +'"></ul>');
            else
                $('.wpr-tab-search-result').append('<div class="arrows_search_tab_desk"><div class="top_arrow"></div><div class="bottom_arrow"></div></div><div class="wpr-block-title">' + keyText + '</div><ul class="createList_tab ' + key + '" id="'+ key +'"></ul>');
    
            }
            if(numberOfKeys==1)
            {
                if (screenSize < 768)
			$('.wpr-search-result').append('<ul class="createList_mobile ' + key + '" id="'+ key +'"></ul>');
		else
			$('.wpr-tab-search-result').append('<div class="arrows_search_tab_desk"><div class="top_arrow"></div><div class="bottom_arrow"></div></div><ul class="createList_tab ' + key + '" id="'+ key +'"></ul>');
            }
		
			if (screenSize <= 768){
				//do nothing
			}else{
				$('.overlay_closing_search').show();
				$('.arrows_search_tab_desk').show();
			}
		
			$.each(value, function (index, dvalue) {
         
            var sResultURL2;
            if(!((key.toLowerCase()).indexOf('store')>=0))
            {
                sResultURL2 = sResultURL + dvalue;
            }
            
            else{
                var sResult=$('#sRUrl2').text();
                sResultURL2=sResult.insert(52,dvalue);
			}
			
			function replacer(match) {
				  return '<span>'+match+'</span>';
			  }
			  var dvalue = dvalue.replace(RegExp(text, "gi"), replacer);

			if (screenSize < 768)
				$('#' + key).append('<li class="listCreated_mobile">  <a onfocus="insertToSearchMobile(this)" tabindex="1" href="' + sResultURL2 + '">' + dvalue + '</a> </li>');
			else
				$('#' + key).append('<li class="listCreated_tab">  <a onfocus="insertToSearch(this)" tabindex="4" href="' + sResultURL2 + '">' + dvalue + '</a> </li>');

			if (index == (keyNumber - 1)) {
				return false;
			}
		});
	}else{
		$('#search_focus_desktop').attr('title',searchTooltip1);
	}
		// (".createList_tab").append("<li class='listCreated_tab'> <a href='" +
		// sResultURL2 + "'> " + items[i].term0 + "</a> </li>");
	});
}

var updateAutoSuggestions = function (qterm) {
	var map = new Map();
	var allStoreData = JSON.parse(sessionStorage.getItem(title1.toLowerCase()));
	var hpStore = JSON.parse(sessionStorage.getItem(title2.toLowerCase()));
	var hpStore2 = JSON.parse(sessionStorage.getItem(title3.toLowerCase()));
	var allStoreHPArray = [];
	var hpStoreArray = [];
	var hpStoreArray2 = [];

	if (allStoreData != null) {
		for (i = 0; i < allStoreData.length; ++i) {

			if (!(allStoreData[i].indexOf(qterm) < 0)) {
				allStoreHPArray.push(allStoreData[i]);
			}
		}
		map.set(title1, allStoreHPArray);
	}
	if (hpStore != null) {
		for (i = 0; i < hpStore.length; ++i) {

			if (!(hpStore[i].indexOf(qterm) < 0)) {

				hpStoreArray.push(hpStore[i]);
			}
		}
		map.set(title2, hpStoreArray);
	}

	if (hpStore2 != null) {
		for (i = 0; i < hpStore2.length; ++i) {

			if (!(hpStore2[i].indexOf(qterm) < 0)) {
				hpStoreArray2.push(hpStore2[i]);
			}
		}
		map.set(title3, hpStoreArray2);
	}
	displayMap(map, qterm);
}

var addSessionCache = function (query, suggestionList) {

    
	sessionStorage.setItem(query.toLowerCase(), JSON.stringify(suggestionList));
	// sessionStorage.setItem("key", query);
}

var UpdateCacheForStore = function (reSet, suggestionList) {
	sessionStorage.setItem(reSet, JSON.stringify(suggestionList));
}

var getSearchResultsURL = function (key) {
	var url=$("#sRUrl").text();
	return url;
}